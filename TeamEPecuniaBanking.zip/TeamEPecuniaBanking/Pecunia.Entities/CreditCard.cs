﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Creditcard.Entities
{
    public class CreditCard
    {
        
        public string AccountNo { get; set; }
       
       
        public string CustomerName { get; set; }
       
        
        public string CardNumber { get; set; }
        
        
        public static double CreditLimit { get; set; }
        
        
        public DateTime StartDate { get; set; }
        

        
        public string CardType { get; set; }
       
       
        public string CardStatus { get; set; }
        
    }
}

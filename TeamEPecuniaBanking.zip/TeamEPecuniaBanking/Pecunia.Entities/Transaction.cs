﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    public class Transaction
    {
       

        public string CreditAccountNumber { get; set; }
        
        
        public string DebitAccountNumber { get; set; }
        
        

        public double Ammount { get; set; }
        
        public string TransactionType { get; set; }

        
        
        public DateTime TransactionTime { get; set; }
       
        
        public Transaction()
        {
            DebitAccountNumber = string.Empty;
            CreditAccountNumber = string.Empty;
            Ammount = 0;
            TransactionType = string.Empty;
            
        }
    }


}

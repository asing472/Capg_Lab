﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    public class Employee
    {
        public int EmployeeID { get; set; }

        public string EmployeeName { get; set; }
        
        public string EmployeeEmail { get; set; }
        
        public string EmployeePassword { get; set; }
        

        Employee()
        {
            EmployeeID = 0;
            EmployeeName = string.Empty;
            EmployeeEmail = string.Empty;
            EmployeePassword = string.Empty;
        }
    }
}

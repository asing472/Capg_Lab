﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string CustomerContactNumber { get; set; }
        public string CustomerEmailID { get; set; }
        public string CustomerAddress { get; set; }
        public DateTime CustomerDOB { get; set; }
        public string CustomerPANno { get; set; }
        public double CustomerAadharno { get; set; }
        public char CustomerGender { get; set; }



        //Default constructor
        public Customer()
        {
            CustomerID = 0;
            CustomerName = string.Empty;
            CustomerContactNumber = string.Empty;
            CustomerEmailID = string.Empty;
            CustomerAddress = string.Empty;
            CustomerDOB = DateTime.Now;
            CustomerPANno = string.Empty;
            CustomerAadharno = 0;


        }
    }

}

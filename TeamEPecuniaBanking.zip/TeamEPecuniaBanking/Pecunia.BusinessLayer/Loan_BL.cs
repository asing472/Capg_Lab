﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.DataAccessLayer;
using Loan_Entities;
using Pecunia.Exceptions;



namespace Pecunia.BusinessLayer
{
    public class Loan_BL
    {
        public static bool validation(Loan L)
        {
            StringBuilder sb = new StringBuilder();
            bool loanad = true;
            if (L.Loan_Amt <= 50000)
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Applied amt cannot be less than 50000");

            }
            if (L.Tenure <= 0)
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Tenure should be greater than 0");

            }
            if ((L.Loan_type != "Home") || (L.Loan_type != "Education") || (L.Loan_type != "Personal") || (L.Loan_type != "Car"))
            {
                loanad = false;
                sb.Append(Environment.NewLine + "loan type can be home,education,personal or car only");

            }
            if (L.YearlyIncome <= 100000)
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Yearly Income should be greater than 1 lakh");

            }
            if (L.Years_of_service <= 5)
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Years of service   should be greater than 5 Years");

            }
            if (loanad == false)
                throw new PecuniaException(sb.ToString());

            return loanad;
        }
        public static bool ApplyLoan(Loan LS)
        {
            bool LoanApplied = false;
            try
            {
                if (validation(LS))
                {
                    Loan L = new Loan();
                    Loan_DAL.LoanServices ser = new Loan_DAL.LoanServices();
                    LoanApplied = ser.new_loan(L);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return LoanApplied;
        }


        public static Loan LoanByID(string LID)
        {
            Loan L = null;
            try
            {
                Loan_DAL.LoanServices LS = new Loan_DAL.LoanServices();
                L = LS.Loan_By_ID(LID);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return L;

        }

        public static Loan LoanByType(string type)
        {
            List<Loan> L = null;
            try
            {
                Loan_DAL.LoanServices LS = new Loan_DAL.LoanServices();
                L = LS.Loan_By_ID(LID);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return L;




        }
        public class Carloan_BL
    {
        public bool validation(CarLoan L)
        {
            StringBuilder sb = new StringBuilder();
            bool loanad = true;
            if (L.License.Length != 9)
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Invalid License Id");
                if (loanad == false)
                    throw new PecuniaException(sb.ToString());
            }
            return loanad;
        }


    }
    public class Home_BL
    {
        public bool validation(HomeLoan L)
        {
            StringBuilder sb = new StringBuilder();
            bool addedLoan = true;
            if (L.Collateral < L.Loan_Amt)
            {
                addedLoan = false;
                sb.Append(Environment.NewLine + "Collateral should be greater than amount applied");
            }
            if (addedLoan == false)
                throw new PecuniaException(sb.ToString());

            return addedLoan;
        }

    }
    public class Personal_BL
    {
        public bool validation(PersonalLoan L)
        {
            StringBuilder sb = new StringBuilder();
            bool loanad = true;
            if (L.Collateral < L.Loan_Amt)
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Collateral should be greater than amount applied");

            }
            if (loanad == false)
                throw new PecuniaException(sb.ToString());

            return loanad;
        }

    }
    public class Education_loan_BL
    {
        public bool validation(EducationLoan L)
        {
            StringBuilder sb = new StringBuilder();
            bool loanad = true;
            if (L.Collateral < L.Loan_Amt)
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Collateral should be greater than amount applied");

            }
            if (L.College_name == "")
            {
                loanad = false;
                sb.Append(Environment.NewLine + "College name should be there");

            }
            if (L.Sponseror == "")
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Sponseror should be there if no sponseror then write self");

            }
            if (L.Admission_ID == "")
            {
                loanad = false;
                sb.Append(Environment.NewLine + "Admission ID should be there");

            }
            if (loanad == false)
                throw new PecuniaException(sb.ToString());
            return loanad;
        }

    }



}

}
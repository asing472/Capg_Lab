﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    public class AccountBL
    {

        //Validating the account details
        private static bool ValidateAccount(Account account)
        {
            StringBuilder sb = new StringBuilder();
            bool validAccount = true;
            if (account.Balance < account.MinimumBalance)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Account balance can't be less than minimum balance");

            }
            if (account.MinimumBalance < 0)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Minimum balance can't be zero");

            }
            if (account.InterestRate < 0)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Interest rate can't be negative");

            }
            if (account.Tenure < 0)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Tenure can't be negative");

            }
            /*if (account.StartDate == DateTime.MinValue)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "StartDate can't be null");

            }*/
            if ((account.AccountType != "Savings") && (account.AccountType != "Current") && (account.AccountType != "Fixed"))
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "AccountType can be Savings or Current or Fixed");

            }

            Regex pattern = new Regex(@"[A-Z][A-Za-z\s]$");
            if ((account.aCustomerName.Length > 40) || (pattern.IsMatch(account.aCustomerName) == false))
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Customer Name invalid or exceeds 40 characters");

            }

            if (validAccount == false)
                throw new PecuniaException(sb.ToString());
            return validAccount;
        }

        public static bool CreateAccountBL(Account newAccount)
        {
            bool AccountCreated = false;
            try
            {
                if (ValidateAccount(newAccount))
                {
                    AccountDAL accountDAL = new AccountDAL();
                    AccountCreated = accountDAL.CreateAccountDAL(newAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return AccountCreated;
        }

        public static List<Account> GetAllAccountsBL()
        {
            List<Account> AccountList = null;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                AccountList = accountDAL.GetAllAccountsDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return AccountList;
        }

        public static Account SearchAccountBL(string searchAccountNo)
        {
            Account searchAccount = null;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                searchAccount = accountDAL.SearchAccountDAL(searchAccountNo);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchAccount;

        }

        public static List<Account> GetAccountsByCustomerIDBL(string searchCustomerID)
        {

            List<Account> AccountsByCustID = null;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                AccountsByCustID = accountDAL.GetAccountsByCustomerIDDAL(searchCustomerID);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByCustID;

        }

        public static List<Account> GetAccountsByCustomerNameBL(string searchCustomerName)
        {

            List<Account> AccountsByCustomerName = null;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                AccountsByCustomerName = accountDAL.GetAccountsByCustomerNameDAL(searchCustomerName);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByCustomerName;

        }

        public static List<Account> GetAccountsByTypeBL(string searchAccountType)
        {

            List<Account> AccountsByType = null;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                AccountsByType = accountDAL.GetAccountsByTypeDAL(searchAccountType);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByType;

        }

        public static List<Account> GetAccountsByBranchBL(string searchBranch)
        {

            List<Account> AccountsByBranch = null;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                AccountsByBranch = accountDAL.GetAccountsByBranchDAL(searchBranch);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByBranch;

        }

        public static double GetBalanceBL(string accountNumber)
        {

            double balance = 0;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                balance = accountDAL.GetBalanceDAL(accountNumber);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return balance;

        }

        public static bool UpdateBalanceBL(string accountNumber,double balance)
        {

            bool BalanceUpdated = false;
            
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                BalanceUpdated = accountDAL.UpdateBalanceDAL(accountNumber, balance);
                
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return BalanceUpdated;
        }

        public static bool UpdateBranchBL(string accountNumber, string branch)
        {
            bool AccountBranchUpdated = false;
            try
            {
                Regex rgx = new Regex(@"^[1]{1}[0-9]{9}$");


                if ((rgx.IsMatch(accountNumber) == true)&&((branch == "Mumbai")||(branch == "Bangalore")||(branch == "Chennai")||(branch == "Delhi")))
                {
                    AccountDAL accountDAL = new AccountDAL();
                    AccountBranchUpdated = accountDAL.UpdateBranchDAL(accountNumber,branch);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
               
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return AccountBranchUpdated;
        }

        public static bool UpdateAccountTypeBL(string accountNumber, string branch, double tenure)
        {
            bool AccountTypeUpdated = false;
            try
            {
                Regex rgx = new Regex(@"^[1]{1}[0-9]{9}$");


                if ((rgx.IsMatch(accountNumber) == true) && ((branch == "Mumbai") || (branch == "Bangalore") || (branch == "Chennai") || (branch == "Delhi"))&&(tenure > 0))
                {
                    AccountDAL accountDAL = new AccountDAL();
                    AccountTypeUpdated = accountDAL.UpdateAccountTypeDAL(accountNumber, branch, tenure);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }

            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return AccountTypeUpdated;
        }

        public static bool DeleteAccountBL(string deleteAccountNo)
        {
            bool AccountDeleted = false;
            try
            {
                Regex rgx = new Regex(@"^[1]{1}[0-9]{9}$");

                if (rgx.IsMatch(deleteAccountNo) == true)
                {
                    AccountDAL accountDAL = new AccountDAL();
                    AccountDeleted = accountDAL.DeleteAccountDAL(deleteAccountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return AccountDeleted;
        }

    }
}

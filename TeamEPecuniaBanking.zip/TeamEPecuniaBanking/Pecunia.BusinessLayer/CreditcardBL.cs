﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Creditcard.Entities;
using Creditcard.DataAccessLayer;
using Pecunia.Exceptions;


namespace CredicCard.BusinessLayer

{
    public class CreditCardBL
    {
        private static bool ValidateCreditCard(CreditCard creditCard)
        {
            StringBuilder sb = new StringBuilder();
            bool validCreditCard = true;


            if (creditCard.CardType != "Platinum Plus" && creditCard.CardType != "Visa Signature" && creditCard.CardType != "Infinia")
            {
                validCreditCard = false;
                sb.Append(Environment.NewLine + "Card Type should be Platinum Plus  or Visa Signature or Infinia ");

            }
            //credit limit validation
            if (validCreditCard == false)
            {
                throw new PecuniaException(sb.ToString());
            }
            return validCreditCard;
        }

        public static bool NewCreditCardIssueBL(CreditCard creditCard)
        {
            bool creditCardIssued = false;
            try
            {
                if (ValidateCreditCard(creditCard))
                {
                    CreditCardDAL creditCardDAL = new CreditCardDAL();
                    creditCardIssued = creditCardDAL.NewCreditCardIssueDAL(creditCard);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return creditCardIssued;
        }
        public static List<CreditCard> GetCreditCardListBL()
        {
            List<CreditCard> creditCardList = null;
            try
            {
                CreditCardDAL creditCardDAL = new CreditCardDAL();
                creditCardList = creditCardDAL.GetCreditCardListDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return creditCardList;
        }
        public static bool UpdateCreditCardStatusBL(string accountNo)
        {
            bool updateCardStatus = false;
            try
            {
                if (accountNo != null)
                {
                    CreditCardDAL creditCardDAL = new CreditCardDAL();
                    updateCardStatus = creditCardDAL.UpdateCreditCardStatusDAL(accountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid accountNo");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return updateCardStatus;
        }


        public static List<CreditCard> GetBlockedDebitCardListBL()
        {
            List<CreditCard> blockedCardList = null;
            try
            {
                CreditCardDAL creditCardDAL = new CreditCardDAL();
                blockedCardList = creditCardDAL.GetBlockedCreditCardListDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blockedCardList;
        }
    }
}

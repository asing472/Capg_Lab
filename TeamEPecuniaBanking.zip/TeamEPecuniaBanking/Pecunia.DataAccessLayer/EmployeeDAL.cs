﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;

namespace Pecunia.DataAccessLayer
{
    public class EmployeeDAL
    {
        public static List<Employee> employeeList = new List<Employee>();


        public bool AddEmployeeDAL(Employee newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                employeeList.Add(newEmployee);
                employeeAdded = true;
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return employeeAdded;

        }


        public List<Employee> GetAllEmployeesDAL()
        {
            return employeeList;
        }


        public Employee GetEmployeeByEmplyeeIdDAL(int searchEmployeeID)
        {
            Employee searchEmployee = null;
            try
            {
                foreach (Employee item in employeeList)
                {
                    if (item.EmployeeID == searchEmployeeID)
                    {
                        searchEmployee = item;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchEmployee;
        }


        public Employee GetEmployeeByEmplyeeNameDAL(string searchEmployeeName)
        {
            Employee searchEmployee = null;
            try
            {
                foreach (Employee item in employeeList)
                {
                    if (item.EmployeeName == searchEmployeeName)
                    {
                        searchEmployee = item;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchEmployee;
        }


        public bool GetEmplyeeByIDandPassworDAl(int checkEmployeeId, string checkEmployeePassword)
        {
            bool checkEmployee = false;
            try
            {
                foreach (Employee item in employeeList)
                {
                    if (item.EmployeeID == checkEmployeeId && item.EmployeePassword == checkEmployeePassword)
                    {
                        checkEmployee = true;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return checkEmployee;
        }


        public bool UpdateEmployeeDAL(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                for (int i = 0; i < employeeList.Count; i++)
                {
                    if (employeeList[i].EmployeeID == updateEmployee.EmployeeID)
                    {
                        updateEmployee.EmployeeName = employeeList[i].EmployeeName;
                        updateEmployee.EmployeeEmail = employeeList[i].EmployeeEmail;
                        updateEmployee.EmployeePassword = employeeList[i].EmployeePassword;
                        employeeUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return employeeUpdated;

        }


        public bool DeleteEmployeetDAL(int deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                Employee deleteEmployee = null;
                foreach (Employee item in employeeList)
                {
                    if (item.EmployeeID == deleteEmployeeID)
                    {
                        deleteEmployee = item;
                    }
                }

                if (deleteEmployee != null)
                {
                    employeeList.Remove(deleteEmployee);
                    employeeDeleted = true;
                }
            }
            catch (Exception ex) { throw new PecuniaException(ex.Message); }
            
            return employeeDeleted;

        }




    }
}

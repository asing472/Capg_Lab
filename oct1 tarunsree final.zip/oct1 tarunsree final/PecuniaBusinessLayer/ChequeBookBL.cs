﻿using Pecunia.Entities;

using Pecunia.Exceptions;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.BusinessLayer
{/// <summary>
 /// Contains data access layer methods for inserting, updating and searching debitcards from ChequeBooks collection.
 /// </summary>


    public class ChequeBookBL : BLBase<ChequeBook>, iChequeBookBL, IDisposable
    {
        //fields
        ChequeBookDALBase chequeBookDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public ChequeBookBL()
        {
            this.chequeBookDAL = new ChequeBookDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(ChequeBook entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject); 
            if(entityObject.ChequeBookStatus=="Requested"&& entityObject.ChequeBookStatus == "Approved" )
            {
                valid = false;
                sb.Append(Environment.NewLine + "Status should be either Requested or Approved ");
            }
            if (entityObject.NumberOfLeaves % 5 != 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Enter valid number of pages");

            }

            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new ChequeBook to ChequeBook collection.
        /// </summary>
        /// <param name="newChequeBook">Contains the ChequeBook details to be added.</param>
        /// <returns>Determinates whether the new ChequeBook is added.</returns>
        public async Task<bool> AddChequeBookBL(ChequeBook newChequeBook)
        {
            bool ChequeBookAdded = false;
            try
            {
                if (await Validate(newChequeBook))
                {
                    await Task.Run(() =>
                    { 
                        this.chequeBookDAL.AddChequeBookDAL(newChequeBook);

                        ChequeBookAdded = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return ChequeBookAdded;
        }
        /// <summary>
        /// Gets all ChequeBooks from the collection.
        /// </summary>
        /// <returns>Returns list of all ChequeBooks.</returns>
        public async Task<List<ChequeBook>> GetAllChequeBooksBL()
        {
            List<ChequeBook> ChequeBooksList = null;
            try
            {
                await Task.Run(() =>
                {
                    ChequeBooksList = chequeBookDAL.GetChequeBookListDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return ChequeBooksList;
        }
        /// <summary>
        /// Gets ChequeBook based on ChequeBookID.
        /// </summary>
        /// <param name="searchChequeBookID">Represents ChequeBookID to search.</param>
        /// <returns>Returns ChequeBook object.</returns>
        public async Task<ChequeBook> GetChequeBookByChequeBookIdBL(Guid searchChequeBookID)
        {
            ChequeBook matchingChequeBook = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingChequeBook = chequeBookDAL.GetChequeBookByChequeBookIdDAL(searchChequeBookID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingChequeBook;
        }
        public async Task<ChequeBook> GetChequeBookBySeriesStartBL(double seriesStart)
        {
            ChequeBook matchingChequeBook = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingChequeBook = chequeBookDAL.GetChequeBookBySeriesStartDAL(seriesStart);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingChequeBook;
        }
        /// <summary>
        /// Gets ChequeBook based on AccountId.
        /// </summary>
        /// <param name="Accountid">Represents AccountId to search.</param>
        /// <returns>Returns List of cheque book objects with same account id.</returns>
        public async Task<List<ChequeBook>> GetChequeBooksByAccountIdBL(Guid AccountId)
        {
            List<ChequeBook> matchingChequeBooks = new List<ChequeBook>();
            try
            {
                await Task.Run(() =>
                {
                    matchingChequeBooks = chequeBookDAL.GetChequeBooksByAccountIdDAL(AccountId);
                }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingChequeBooks;
        }
        public async Task<List<ChequeBook>> GetChequeBooksByAccountIdAndStatusBL(Guid AccountId,string status)
        {
            List<ChequeBook> matchingChequeBooks = new List<ChequeBook>();
            try
            {
                await Task.Run(() =>
                {
                    matchingChequeBooks = chequeBookDAL.GetChequeBooksByAccountIdAndStatusDAL(AccountId,status);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingChequeBooks;
        }
        /// <summary>
        /// Updates chequeBook status based on ChequeBookId.
        /// </summary>
        /// <param name="chequeBookId">Represents ChequeBook details </param>
        /// <returns>Determinates whether the existing ChequeBook's status is updated.</returns>
        public async Task<bool> UpdateChequeBookStatusBL(ChequeBook chequeBook)
        {
            bool statusUpdated = false;
            try
            {
                if ((await GetChequeBookByChequeBookIdBL(chequeBook.ChequeBookId)) != null)
                {
                    this.chequeBookDAL.UpdateChequeBookStatusDAL(chequeBook);
                    statusUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return statusUpdated;
        }


        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((ChequeBookDAL)chequeBookDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public void Serialize()
        {
            try
            {
                chequeBookDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public void Deserialize()
        {
            try
            {
                chequeBookDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

﻿using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Helpers;

namespace Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating and searching debitcards from DebitCards collection.
    /// </summary>


    public class DebitCardBL : BLBase<DebitCard>, IDebitCardBL, IDisposable
    {
        //fields
        DebitCardDALBase DebitCardDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public DebitCardBL()
        {
            this.DebitCardDAL = new DebitCardDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(DebitCard entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

           
            if (entityObject.CardType != "Rupay" && entityObject.CardType != "VISA" && entityObject.CardType != "maestro" && entityObject.CardType != "mastercard")
            {
                valid = false;
                sb.Append(Environment.NewLine + "Card Type should be Rupay or VISA or maestro or mastercard ");

            }

            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new DebitCard to DebitCards collection.
        /// </summary>
        /// <param name="newDebitCard">Contains the DebitCard details to be added.</param>
        /// <returns>Determinates whether the new DebitCard is added.</returns>
        public async Task<bool> AddDebitCardBL(DebitCard newDebitCard)
        {
            bool DebitCardAdded = false;
            try
            {
                if (await Validate(newDebitCard))
                {
                    await Task.Run(() =>
                    {
                        //Credit Card No generator
                        if (DebitCardDALBase.debitCardsList.Count == 0)
                        {
                            newDebitCard.CardNumber = Convert.ToString(CardConfiguration.baseDebitCardNumber);
                        }
                        else
                        {
                            int d = DebitCardDALBase.debitCardsList.Count();
                            long nextCardNo = CardConfiguration.baseDebitCardNumber + d;
                            newDebitCard.CardNumber = nextCardNo.ToString();

                        }
                        this.DebitCardDAL.AddDebitCardDAL(newDebitCard);
                        DebitCardAdded = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return DebitCardAdded;
        }
        /// <summary>
        /// Gets all DebitCards from the collection.
        /// </summary>
        /// <returns>Returns list of all DebitCards.</returns>
        public async Task<List<DebitCard>> GetAllDebitCardsBL()
        {
            List<DebitCard> DebitCardsList = null;
            try
            {
                await Task.Run(() =>
                {
                    DebitCardsList = DebitCardDAL.GetDebitCardListDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return DebitCardsList;
        }
        /// <summary>
        /// Gets DebitCard based on DebitCardID.
        /// </summary>
        /// <param name="searchDebitCardID">Represents DebitCardID to search.</param>
        /// <returns>Returns DebitCard object.</returns>
        public async Task<DebitCard> GetDebitCardByDebitCardNumberBL(string searchDebitCardnumber)
        {
            DebitCard matchingDebitCard = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingDebitCard = DebitCardDAL.GetDebitCardByDebitCardNumberDAL( searchDebitCardnumber);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingDebitCard;
        }
        /// <summary>
        /// Gets DebitCard based on AccountId.
        /// </summary>
        /// <param name="Accountid">Represents DebitCardId to search.</param>
        /// <returns>Returns List of debit card objects with same account id.</returns>
        public async Task<List<DebitCard>> GetDebitCardsByAccountIdBL(Guid AccountId)
        {
            List<DebitCard> matchingDebitCards = new List<DebitCard>();
            try
            {
                await Task.Run(() =>
                {
                    matchingDebitCards = DebitCardDAL.GetDebitCardsByAccountIdDAL(AccountId);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingDebitCards;
        }
        /// <summary>
        /// Updates debit card status based on DebitCardId.
        /// </summary>
        /// <param name="\debitCardId">Represents DebitCard Id for which status is to be updated.</param>
        /// <param name="\card Status">Represents DebitCard Id for which status is to be updated.</param>
        /// <returns>Determinates whether the existing DebitCard's status is updated.</returns>
        public async Task<bool> UpdateDebitCardStatusBL(string debitCardNumber, string cardStatus)
        {
            bool statusUpdated = false;
            try
            {
                if ((await GetDebitCardByDebitCardNumberBL(debitCardNumber)) != null)
                {
                    this.DebitCardDAL.UpdateDebitCardStatusDAL(debitCardNumber, cardStatus);
                    statusUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return statusUpdated;
        }


        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((DebitCardDAL)DebitCardDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public void Serialize()
        {
            try
            {
                DebitCardDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public void Deserialize()
        {
            try
            {
                DebitCardDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

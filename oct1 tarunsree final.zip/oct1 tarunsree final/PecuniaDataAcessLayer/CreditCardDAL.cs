﻿using Pecunia.Entities;
using Pecunia.Contracts.DALContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.DataAcessLayer
{
    /// <summary>
    /// Contains  methods for inserting, updating and searching creditcards from CreditCards collection.
    /// </summary>

    public class CreditCardDAL : CreditCardDALBase, IDisposable
    { /// <summary>
      /// Adds new credit card to CreditCards collection.
      /// </summary>
      /// <param name="creditCard">Contains the credit card details to be added.</param>
      /// <returns>Determinates whether the new credit card is added.</returns>
        public override bool AddCreditCardDAL(CreditCard creditCard)
        {
            bool creditCardIssued = false;
            try
            {
                creditCard.CreditCardId = Guid.NewGuid();
                creditCard.CardStatus = "Issued";
                creditCard.CardIssueDate = DateTime.Now;
                creditCard.LastModifiedDate = DateTime.Now;
                DateTime ExDate = creditCard.CardIssueDate.AddYears(5);
                double year= Convert.ToInt32(ExDate.ToString("yyyy"));
                double month= Convert.ToInt32(ExDate.ToString("MM"));
                creditCard.ExpiryMMYYYY = Convert.ToString(month) + "/" + Convert.ToString(year);
                creditCardsList.Add(creditCard);
                creditCardIssued = true;
            }
            catch (Exception)
            {
                throw;
            }
            return creditCardIssued;

        }
        /// <summary>
        /// Returns credit card list
        /// </summary>
        /// <returns> Returns the list of credit  cards</returns>
        public override List<CreditCard> GetCreditCardListDAL()
        {
            return creditCardsList;
        }
        /// <summary>
        /// Updates the status of credit card
        /// </summary>
        /// <param name="creditId">Contains the creditId for which we need to change status</param>
        /// <param name="cardStatus">Employee gives the input like active or blocked as per user request</param>
        /// <returns>Returns bool value if updated or not</returns>
        public override bool UpdateCreditCardStatusDAL(string creditCardNumber, string cardStatus)
        {
            bool creditCardStatusChanged = false;
            try
            {
                CreditCard creditCard = null;
                creditCard = creditCardsList.Find(x => x.CardNumber == creditCardNumber);

                if (creditCard != null)
                {

                    creditCard.CardStatus = cardStatus;
                    creditCard.LastModifiedDate = DateTime.Now;

                    creditCardStatusChanged = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return creditCardStatusChanged;
        }
        /// <summary>
        /// Gets creditCard based on creditCardID.
        /// </summary>
        /// <param name="creditId">Represents CreditCardID to search.</param>
        /// <returns>returns credit card details for respective credit card Id</returns>
        public override CreditCard GetCreditCardByCreditCardNumberDAL(string cardNumber)
        {
            CreditCard searchCredit = null;
            try
            {
                searchCredit = creditCardsList.Find(x => x.CardNumber == cardNumber);
            }
            catch (Exception)
            {
                throw;
            }
            return searchCredit;
        }
        /// <summary>
        /// Gets list of creditCards based on CustomerID.
        /// </summary>
        /// <param name="customerId">Represents CustomerID to search.</param>
        /// <returns>returns list of credit cards details for respective CustomerId</returns>
        public override List<CreditCard> GetCreditCardsByCustomerIdDAL(Guid customerId)
        {
            List<CreditCard> CreditCardsByCustomerID = new List<CreditCard>();
            try
            {

                CreditCardsByCustomerID.AddRange(creditCardsList.FindAll(x => x.CustomerId == customerId));

            }
            catch (Exception)
            {
                throw;
            }
            return CreditCardsByCustomerID;
        }



        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }

    }
}

﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{

    public interface ITransactionsBL : IDisposable
    {
        Task<bool> AddTransactionBL(Transaction newTransaction);
        Task<List<Transaction>> GetAllTransactionsBL();
        Task<List<Transaction>> GetAllTransactionsByTransactionTypeBL(string transactionType);
        Task<List<Transaction>> GetAllTransactionsByAccountNumberBL(string accountNumber);
        Task<List<Transaction>> GetAllTransactionsByTimeBL(DateTime transactionTime);
    }
}

﻿using Pecunia.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using Pecunia.BusinessLayer;
using Pecunia.Entities;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.Exceptions;

namespace Pecunia.PresentationLayer
{
    class Program
    {
        static async Task Main(string[] args)
        {
            try
            {

                //showing the login screen
                int internalChoice = -2;
                WriteLine("=============== PECUNIA BANKING SYSTEM =========================");
                do
                {
                    UserType userType = await ShowLoginScreen();
                    if (userType == UserType.Admin)
                    {
                        internalChoice = await AdminPresentation.AdminUserMenu();
                    }
                    else if (userType == UserType.Employee)
                    {
                        internalChoice = await EmployeePresentation.EmployeeUserMenu();
                    }
                } while (internalChoice != -1);
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
            WriteLine("Thank you!");
            ReadKey();
        }
        //login screen menu, if user is admin or employee he will be redirected to respective  menu
        static async Task<UserType> ShowLoginScreen()
        {
            //Read inputs
            string email, password;
            WriteLine("=====LOGIN=========");
            Write("Email: ");
            email = ReadLine();
            Write("Password: ");
            password = ReadLine();

            using (IAdminBL adminBL = new AdminBL())
            {
                //Invoke GetAdminByEmailAndPasswordBL for checking email and password of Admin
                Admin admin = await adminBL.GetAdminByEmailAndPasswordBL(email, password);
                if (admin != null)
                {
                    return UserType.Admin;
                }
            }

            using (IEmployeeBL employeeBL = new EmployeeBL())
            {
                //Invoke GetAdminByEmailAndPasswordBL for checking email and password of Admin
                Employee employee = await employeeBL.GetEmployeeByEmailAndPasswordBL(email, password);
                if (employee != null)
                {
                    return UserType.Employee;
                }
            }

            WriteLine("Invalid Email or Password. Please try again...");
            return UserType.Anonymous;
        }
    }
}

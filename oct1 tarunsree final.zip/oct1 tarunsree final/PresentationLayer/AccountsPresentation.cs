﻿using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Pecunia.PresentationLayer
{
    class AccountsPresentation
    {
        /// <summary>
        /// Menu for Accounts Service
        /// </summary>
        /// <returns></returns>
        public static async Task<int> AccountsMenu()
        {
            int choice = -2;

            do
            {
                //Menu
                WriteLine("\n***********Accounts Menu***********");
                WriteLine("1. Create new account");
                WriteLine("2. Update/Modify account");
                WriteLine("3. Delete account");
                WriteLine("4. Search account");
                WriteLine("0. Logout");
                //WriteLine("-1. Exit");
                Write("Choice : ");
                //Accept and check choice
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1:
                            await CreateAccount();
                            break;
                        case 2:
                            await UpdateAccount();
                            break;
                        case 3:
                            await DeleteAccount();
                            break;
                        case 4:
                            await SearchAccount();
                            break;
                        case 0: break;

                    }
                }
                else
                {
                    choice = -2;
                }
            } while (choice != 0 && choice != -1);
            
            return choice;
        }


        /// <summary>
        /// Creating a new account
        /// </summary>
        /// <returns></returns>
        public static async Task CreateAccount()
        {
            CustomerBL cbl = new CustomerBL();
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {
                //Asking whether the customer already exists or not
                WriteLine("Enter 1 for existing customer\n");
                WriteLine("Enter 2 for new customer\n");
                int ch = Convert.ToInt32(Console.ReadLine());

                //When the customer already exists
                if (ch == 1)
                {
                    Console.WriteLine("Enter Customer No :");
                    string searchCustomerNo = Console.ReadLine();
                    Customer customer = await cbl.GetCustomerByCustomerNumberBL(searchCustomerNo);
                    Console.WriteLine("Select the type of account(Savings, Current or Fixed) :");
                    string accType = Console.ReadLine();
                    if (customer != null)
                    {
                        if ((accType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
                        {
                            RegularAccount account = new RegularAccount();
                            WriteLine("Enter a Branch: ");
                            account.Branch = Console.ReadLine();
                            account.CustomerNo = searchCustomerNo;
                            account.CustomerID = customer.CustomerID;
                            account.AccountType = accType;
                            //Write("Enter AccountNo.");
                            //account.AccountNo = ReadLine();
                            bool isAdded = await abl.CreateAccountBL(account);
                            if (isAdded)
                            { 
                                Console.WriteLine(accType + " account created");
                                Console.WriteLine("Account No.generated is: " + account.AccountNo);
                            }
                            else
                                Console.WriteLine("Account not created");

                        }

                        else if (accType.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
                        {
                            FixedAccount fixedacc = new FixedAccount();
                            fixedacc.AccountType = accType;
                            WriteLine("Enter a Branch: ");
                            fixedacc.Branch = Console.ReadLine();
                            fixedacc.CustomerNo = searchCustomerNo;
                            fixedacc.CustomerID = customer.CustomerID;
                            WriteLine("Enter Tenure");
                            fixedacc.Tenure = Double.Parse(Console.ReadLine());
                            WriteLine("Enter FDDeposit Amount: ");
                            fixedacc.FDDeposit = Double.Parse(Console.ReadLine());
                            bool fixaccountCreated = await fbl.CreateAccountBL(fixedacc);
                            if (fixaccountCreated)
                            {
                                Console.WriteLine("Fixed account created");
                                Console.WriteLine("Account No.generated is: " + fixedacc.AccountNo);
                            }
                            else
                                Console.WriteLine("Account not created");
                        }

                        else
                        {
                            Console.WriteLine("Account Type not valid");
                        }
                        
                    }
                    else
                    {

                        Console.WriteLine("No Customer Details Available");

                    }

                }

                //When the customer is a new customer
                if (ch == 2)
                {
                    WriteLine("Enter Customer Details :");
                    await CustomerPresentation.AddCustomer();
                
                    
                    Console.WriteLine("Enter Customer No :");
                    string searchCustomerNo = Console.ReadLine();

                    Customer customer = await cbl.GetCustomerByCustomerNumberBL(searchCustomerNo);
                    Console.WriteLine("Select the type of account(Savings, Current or Fixed) :");
                    string accType = Console.ReadLine();
                    if (customer != null)
                    {
                        if ((accType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
                        {
                            RegularAccount account = new RegularAccount();
                            WriteLine("Enter a Branch: ");
                            account.Branch = Console.ReadLine();
                            account.CustomerNo = searchCustomerNo;
                            account.CustomerID = customer.CustomerID;
                            account.AccountType = accType;
                            //Write("Enter AccountNo.");
                            //account.AccountNo = ReadLine();
                            bool isAdded = await abl.CreateAccountBL(account);
                            if (isAdded)
                            {
                                Console.WriteLine(accType + " account created");
                                Console.WriteLine("Account No.generated is: " + account.AccountNo);
                            }
                            else
                                Console.WriteLine("Account not created");

                        }

                        else if (accType.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
                        {
                            FixedAccount fixedacc = new FixedAccount();
                            fixedacc.AccountType = accType;
                            fixedacc.CustomerID = customer.CustomerID;
                            WriteLine("Enter a Branch: ");
                            fixedacc.Branch = Console.ReadLine();
                            WriteLine("Enter Tenure: ");
                            fixedacc.Tenure = Double.Parse(Console.ReadLine());
                            WriteLine("Enter FDDeposit Amount: ");
                            fixedacc.FDDeposit = Double.Parse(Console.ReadLine());

                            fixedacc.CustomerNo = searchCustomerNo;
                            bool fixaccountCreated = await fbl.CreateAccountBL(fixedacc);
                            if (fixaccountCreated)
                            {
                                Console.WriteLine("Fixed account created");
                                Console.WriteLine("Account No.generated is: " + fixedacc.AccountNo);
                            }
                            else
                                Console.WriteLine("Account not created");
                        }

                        else
                        {
                            Console.WriteLine("Account Type not valid");
                        }

                    }
       
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }


        /// <summary>
        /// Updating the account branch or modifying the account branch
        /// </summary>
        /// <returns></returns>
        public static async Task UpdateAccount()
        {
            //CustomerBL cbl = new CustomerBL();
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {
                Console.WriteLine("Enter 1 for updating branch \n");
                Console.WriteLine("Enter 2 for modifying account type \n");
                int cha = Convert.ToInt32(Console.ReadLine());
                switch (cha)
                {
                    case 1:

                        Console.WriteLine("Enter the account number :\n");
                        string accno = Console.ReadLine();

                        RegularAccount account = await abl.GetAccountByAccountNoBL(accno);
                        FixedAccount fixacc = await fbl.GetAccountByAccountNoBL(accno);

                        if (account != null)
                        {
                            Console.WriteLine("Enter the new account branch :\n");
                            string branch = Console.ReadLine();
                            bool accountBranchUpdated = await abl.UpdateBranchBL(accno, branch);
                            if (accountBranchUpdated)
                                Console.WriteLine("Home branch updated");
                            else
                                Console.WriteLine("Home branch not Updated ");
                        }

                        
                        else if (fixacc != null)
                        {
                            Console.WriteLine("Enter the new account branch :\n");
                            string branch = Console.ReadLine();
                            bool accountBranchUpdated = await fbl.UpdateBranchBL(accno, branch);
                            if (accountBranchUpdated)
                                Console.WriteLine("Home branch updated");
                            else
                                Console.WriteLine("Home branch not Updated ");
                        }

                        else
                        {
                            Console.WriteLine("No customer Details Available");
                        }

                        break;

                    case 2:

                        Console.WriteLine("Enter the account number :\n");
                        string accno2 = Console.ReadLine();
                        RegularAccount account1 = await abl.GetAccountByAccountNoBL(accno2);
                        FixedAccount account2 = await fbl.GetAccountByAccountNoBL(accno2);
                        if (account1 != null)
                        {
                            Console.WriteLine("Enter the new account type(Savings or Current) :\n");
                            string acctype = Console.ReadLine();
                            account1.AccountType = acctype;
                            bool accountTypeUpdated = await abl.UpdateAccountTypeBL(accno2, acctype);
                            if (accountTypeUpdated)
                                Console.WriteLine("Account type updated");
                            else
                                Console.WriteLine("Account type not Updated ");
                        }
                        else if(account2 != null)
                        {
                            Console.WriteLine("Fixed Accounts cannot be changed into other account type");
                        }

                        else
                        {
                            Console.WriteLine("No customer Details Available");
                        }

                        break;

                }
            }
            catch (PecuniaException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Deleting an existing account
        /// </summary>
        /// <returns></returns>
        public static async Task DeleteAccount()
        {
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {

                Console.WriteLine("Enter the account number :\n");
                string accno = Console.ReadLine();
                RegularAccount account1 = await abl.GetAccountByAccountNoBL(accno);
                FixedAccount account2 = await fbl.GetAccountByAccountNoBL(accno);
                if (account1 != null)
                {
                 
                    bool accountDeleted = await abl.DeleteAccountBL(accno);
                    if (accountDeleted)
                        Console.WriteLine("Account deleted");
                    else
                        Console.WriteLine("Account not deleted");
                }

                else if (account2 != null)
                {

                    bool accountDeleted = await fbl.DeleteAccountBL(accno);
                    if (accountDeleted)
                        Console.WriteLine("Account deleted");
                    else
                        Console.WriteLine("Account not deleted");
                }

                else
                {
                    Console.WriteLine("No account details available");
                }
                
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }


        /// <summary>
        /// Searching the accounts based on various criteria
        /// </summary>
        /// <returns>Returns RegularAccount or FixedAccount object</returns>
        public static async Task SearchAccount()
        {
            //CustomerBL cbl = new CustomerBL();
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {
                Console.WriteLine("1.Search account by account number:");
                Console.WriteLine("2.Search accounts by CustomerNo:");
                Console.WriteLine("3.Search accounts by account type:");
                Console.WriteLine("4.Search account by home branch:");
                Console.WriteLine("5.Search account by date:");

                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:

                        string accno;
                        Console.WriteLine("Enter account number to search:");
                        accno = Console.ReadLine();
                        RegularAccount account1 = await abl.GetAccountByAccountNoBL(accno);
                        FixedAccount account2 = await fbl.GetAccountByAccountNoBL(accno);      
                        if (account1 != null)
                        {
                            Console.WriteLine("************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                            Console.WriteLine("************************************************************************************************************");
                            Console.WriteLine($"{account1.CustomerNo}\t {account1.AccountNo}\t {account1.AccountType}\t { account1.CurrentBalance}\t{ account1.Branch}\t {account1.Status}\t {account1.CreationDateTime}\t{account1.LastModifiedDateTime}");
                            Console.WriteLine("************************************************************************************************************");
                        }

                        else if (account2 != null)
                        {
                            Console.WriteLine("*************************************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            Console.WriteLine("*************************************************************************************************************************************");
                            Console.WriteLine($"{account2.CustomerNo}\t {account2.AccountNo}\t {account2.AccountType}\t { account2.CurrentBalance}\t{ account2.Branch}\t {account2.Status}\t{account2.Tenure}\t{account2.FDDeposit}\t{account2.CreationDateTime}\t{account2.LastModifiedDateTime}");
                            Console.WriteLine("*************************************************************************************************************************************");
                        }

                        else
                        {
                            Console.WriteLine("No Account Details Available");
                        }

                        break;

                    case 2:

                        string custNo;
                        Console.WriteLine("Enter customer No to search:");
                        custNo = Console.ReadLine();
                        List<RegularAccount> regaccountsbycustNo = await abl.GetAccountsByCustomerNoBL(custNo);
                        List<FixedAccount> fixaccountsbycustNo = await fbl.GetAccountsByCustomerNoBL(custNo);
                        if (regaccountsbycustNo != null)
                        {
                            Console.WriteLine("************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                            Console.WriteLine("************************************************************************************************************");
                            foreach (RegularAccount regacc1 in regaccountsbycustNo)
                            {
                                Console.WriteLine($"{regacc1.CustomerNo}\t {regacc1.AccountNo}\t {regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                            }
                            Console.WriteLine("************************************************************************************************************");
                        }

                        if (fixaccountsbycustNo != null)
                        {
                            Console.WriteLine("*************************************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            Console.WriteLine("*************************************************************************************************************************************");
                            foreach (FixedAccount acc in fixaccountsbycustNo)
                            {
                                Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            Console.WriteLine("*************************************************************************************************************************************");

                        }

                        else
                        {
                            Console.WriteLine("No Account Details Available");
                        }


                        break;


                    case 3:

                        string accType;
                        Console.WriteLine("Enter account type to search:");
                        accType = Console.ReadLine();

                        if ((accType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
                        {
                            List<RegularAccount> accountsbytype = await abl.GetAccountsByTypeBL(accType);
                            if (accountsbytype != null)
                            {
                                Console.WriteLine("************************************************************************************************************");
                                Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                                Console.WriteLine("************************************************************************************************************");
                                foreach (RegularAccount regacc1 in accountsbytype)
                                {
                                    Console.WriteLine($"{regacc1.CustomerNo}\t {regacc1.AccountNo}\t {regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                                }
                                Console.WriteLine("************************************************************************************************************");
                            }
                            else
                            {
                                Console.WriteLine("No Accounts Details Available");
                            }
                        }
                        else if (accType.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
                        {
                            List<FixedAccount> fixaccounts = await fbl.GetAllAccountsBL();
                            if (fixaccounts != null)
                            {
                                Console.WriteLine("*************************************************************************************************************************************");
                                Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                                Console.WriteLine("*************************************************************************************************************************************");
                                foreach (FixedAccount acc in fixaccounts)
                                {
                                    Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                                }
                                Console.WriteLine("*************************************************************************************************************************************");

                            }

                            else
                            {
                                Console.WriteLine("No Account Details Available");
                            }
                        }

                        else
                        {
                            Console.WriteLine("Account Type not valid");
                        }


                        break;

                    case 4:

                        string branch;
                        Console.WriteLine("Enter home branch to search:");
                        branch = Console.ReadLine();
                        List<RegularAccount> regaccountsbybranch = await abl.GetAccountsByBranchBL(branch);
                        List<FixedAccount> fixaccountsbybranch = await fbl.GetAccountsByBranchBL(branch);

                        if (regaccountsbybranch != null)
                        {
                            Console.WriteLine("************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                            Console.WriteLine("************************************************************************************************************");
                            foreach (RegularAccount regacc1 in regaccountsbybranch)
                            {
                                Console.WriteLine($"{regacc1.CustomerNo}\t {regacc1.AccountNo}\t {regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                            }
                            Console.WriteLine("************************************************************************************************************");
                        }

                        if (fixaccountsbybranch != null)
                        {
                            Console.WriteLine("*************************************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            Console.WriteLine("*************************************************************************************************************************************");
                            foreach (FixedAccount acc in fixaccountsbybranch)
                            {
                                Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            Console.WriteLine("*************************************************************************************************************************************");
                        }

                        else
                        {
                            Console.WriteLine("No Account Details Available");
                        }

                        break;


                    case 5:

                        DateTime date1;
                        DateTime date2;
                        Console.WriteLine("Enter the range of dates to search:");
                        date1 = Convert.ToDateTime(Console.ReadLine());
                        date2 = Convert.ToDateTime(Console.ReadLine());

                        List<RegularAccount> regaccountsbydate = await abl.GetAccountsByAccountOpeningDateBL(date1, date2);
                        List<FixedAccount> fixaccountsbydate = await fbl.GetAccountsByAccountOpeningDateBL(date1, date2);

                        if (regaccountsbydate != null)
                        {
                            Console.WriteLine("************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                            Console.WriteLine("************************************************************************************************************");
                            foreach (RegularAccount regacc1 in regaccountsbydate)
                            {
                                Console.WriteLine($"{regacc1.CustomerNo}\t {regacc1.AccountNo}\t {regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                            }
                            Console.WriteLine("************************************************************************************************************");
                        }

                        if (fixaccountsbydate != null)
                        {
                            Console.WriteLine("*************************************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            Console.WriteLine("*************************************************************************************************************************************");
                            foreach (FixedAccount acc in fixaccountsbydate)
                            {
                                Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            Console.WriteLine("*************************************************************************************************************************************");
                        }

                        else
                        {
                            Console.WriteLine("No Account Details Available");
                        }
                        break;

                }

            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
    }
}
﻿using Pecunia.Helpers.ValidationAttribute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    /// <summary>
    /// Interface for CreditCard Entity
    /// </summary>
    public interface ICreditCard
    {
        Guid CreditCardId { get; set; }
        Guid CustomerId { get; set; }
        
        double CreditLimit { get; set; }
        string CustomerNameAsPerCard { get; set; }
        string CardNumber { get; set; }
        DateTime CardIssueDate { get; set; }
        DateTime LastModifiedDate { get; set; }
        string ExpiryMMYYYY { get; set; }
        string CardType { get; set; }
        string CardStatus { get; set; }

    }
    /// <summary>
    /// Represents CreditCard
    /// </summary>
    public class CreditCard : ICreditCard
    {/* Auto-Implemented Properties */

       
        public Guid CreditCardId { get; set; }
        
        public Guid CustomerId { get; set; }
       
        [Required("Customer Name can't be blank.")]
        [RegExp(@"^(\w{2,40})$", "Customer Name should contain only 2 to 40 characters.")]
        public string CustomerNameAsPerCard { get; set; }
        
        public string CardNumber { get; set; }
        [Required("Credit Limit can't be blank.")]
        public double CreditLimit { get; set; }
        public DateTime CardIssueDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
       
        public string ExpiryMMYYYY { get; set; }
        public string CardType { get; set; }
        public string CardStatus { get; set; }

        public CreditCard()
        {
            CreditCardId = default(Guid);
            CustomerId = default(Guid);
            
            CustomerNameAsPerCard = null;
            CardNumber = null;
            CreditLimit = default(double);
            CardType = null;
            CardStatus = null;
        }


    }

}

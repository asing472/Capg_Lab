﻿using Pecunia.Helpers.ValidationAttribute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    /// <summary>
    /// Interface for DebitCard Entity
    /// </summary>
    public interface IDebitCard
    {
        Guid DebitCardId { get; set; }
        Guid AccountId { get; set; }
        string CustomerNameAsPerCard { get; set; }
        string CardNumber { get; set; }
        DateTime CardIssueDate { get; set; }
        DateTime LastModifiedDate { get; set; }
       string ExpiryMMYYYY { get; set; }
        string CardType { get; set; }
        string CardStatus { get; set; }

    }

    /// <summary>
    /// Represents DebitCard
    /// </summary>
    public class DebitCard : IDebitCard
    {/* Auto-Implemented Properties */

        [Required("DebitCard ID can't be blank.")]
        public Guid DebitCardId { get; set; }
        [Required("Account ID can't be blank.")]
        public Guid AccountId { get; set; }
        [Required("Customer Name can't be blank.")]
        [RegExp(@"^(\w{2,40})$", "Customer Name should contain only 2 to 40 characters.")]
        public string CustomerNameAsPerCard { get; set; }
        public string CardNumber { get; set; }
        public DateTime CardIssueDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public string ExpiryMMYYYY { get; set; }
        public string CardType { get; set; }
        public string CardStatus { get; set; }

        public DebitCard()
        {
            DebitCardId = default(Guid);
            AccountId = default(Guid);
            CustomerNameAsPerCard = null;
            CardNumber = null;
            
            CardType = null;
            CardStatus = null;
        }

    }
}
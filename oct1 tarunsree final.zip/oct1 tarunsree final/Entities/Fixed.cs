﻿using Pecunia.Helpers.ValidationAttribute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    /// <summary>
    /// Interface of Fixed Entity
    /// </summary>
    public interface IFixed
    {
        double Tenure { get; set; }
        double FDDeposit { get; set; }
    }

    /// <summary>
    /// Represents Fixed Deposit Account
    /// </summary>
    public class Fixed : IAccount, IFixed
    {

        /*Auto-Imlemented Properties*/
        [Required("Account ID can't be blank.")]
        public Guid AccountID { get; set; }

        [Required("Customer No can't be blank.")]
        public string CustomerNo { get; set; }

        //[Required("Account No can't be blank.")]
        public string AccountNo { get; set; }

        [Required("Current Balance can't be negative.")]
        public double CurrentBalance { get; set; }

        //[Required("Account Type can't be other than Savings or Current")]
        public string AccountType { get; set; }

        [Required("Branch can't be blank.")]
        public string Branch { get; set; }

        [Required("Status can be either Active or Closed")]
        public string Status { get; set; }

        [Required("Minimum Balance can't be negative.")]
        public double MinimumBalance { get; set; }

        [Required("Interest Rate can't be negative.")]
        public double InterestRate { get; set; }

        [Required("Tenure can't be blank.")]
        public double Tenure { get; set; }

        [Required("FDDeposit can't be negative or blank.")]
        public double FDDeposit { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public Fixed()
        {
            AccountID = default(Guid);
            CustomerNo = null;
            AccountNo = null;
            CurrentBalance = 0;
            AccountType = null;
            Branch = null;
            MinimumBalance = 0;
            InterestRate = 0;
            Status = "Active";
            Tenure = 0;
            FDDeposit = 0;
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Pecunia.Helpers.ValidationAttribute;

namespace Pecunia.Entities
{
    public interface ITransaction
    {
        Guid TransactionID { get; set; }
        string CreditAccountNumber { get; set; }
        string DebitAccountNumber { get; set; }
        double Ammount { get; set; }
        string TransactionType { get; set; }
        DateTime TransactionDateTime { get; set; }

    }
    public class Transaction : ITransaction
    {
        [Required("Transction can't be empty.")]
        public Guid TransactionID { get; set; }


        public string CreditAccountNumber { get; set; }
        public string DebitAccountNumber { get; set; }

        [Required("Ammount can't be blank or zero.")]
        public double Ammount { get; set; }

        [Required("Transaction Type can't be empty")]
        public string TransactionType { get; set; }

        [Required("Transaction date and requiered")]
        public DateTime TransactionDateTime { get; set; }

        public Transaction()
        {
            TransactionID = default(Guid);
            CreditAccountNumber = null;
            DebitAccountNumber = null;
            Ammount = default(double);
            TransactionType = null;
            TransactionDateTime = default(DateTime);
        }

    }
}

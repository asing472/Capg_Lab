﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Exceptions;

namespace Pecunia.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        CustomerService();
                        break;
                    case 2:
                        AccountsService();
                        break;
                    case 3:
                        TransactionService();
                        break;
                    case 4:
                       // LoanServices();
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);

            void TransactionService()
            {
                int tChoice;
                do
                {
                    TransactionMenu();
                    Console.WriteLine("Enter your choice");
                    tChoice = Convert.ToInt32(Console.ReadLine());

                    switch (tChoice)
                    {
                        case 1:
                            Credit();
                            break;

                        case 2:
                            Debit();
                            break;
                        case 3:
                            Transfer();
                            break;
                        case 4:
                            GenerateReport();
                            break;
                    }


                } while (choice != -1);

            }


            void TransactionMenu()
            {
                Console.WriteLine("Select the service you want");
                Console.WriteLine("\n 1. Debit from account");
                Console.WriteLine("\n 2. credit from account");
                Console.WriteLine("\n 3. Transfer within accounts");
                Console.WriteLine("\n Generate Report");
            }

            void Debit()
            {
                Transaction transaction = new Transaction();
                Console.WriteLine("Enter Debit Account Number");
                transaction.DebitAccountNumber = Console.ReadLine();
                Console.WriteLine("Enter the amount you want to debit");
                transaction.Ammount = Convert.ToDouble(Console.ReadLine());
                transaction.TransactionType = "debit";
                transaction.TransactionTime = DateTime.Now;
                bool transactionDone = TransactionBL.DebitTransactionBL(transaction);
                if (transactionDone)
                    Console.WriteLine("Transaction Succesfull");
                else
                    Console.WriteLine("Transaction Failure");

            }
            void Credit()
            {
                Transaction transaction = new Transaction();
                Console.WriteLine("Enter Credit Account Number");
                transaction.CreditAccountNumber = Console.ReadLine();
                Console.WriteLine("Enter the amount you want to credit");
                transaction.Ammount = Convert.ToDouble(Console.ReadLine());
                transaction.TransactionType = "credit";
                transaction.TransactionTime = DateTime.Now;
                bool transactionDone = TransactionBL.CreditTransactionBL(transaction);
                if (transactionDone)
                    Console.WriteLine("Transaction Succesfull");
                else
                    Console.WriteLine("Transaction Failure");
            }
            void Transfer()
            {
                Transaction debitTransaction = new Transaction();
                Transaction creditTransaction = new Transaction();
                Console.WriteLine("Enter Credit Account Number");
                creditTransaction.CreditAccountNumber = Console.ReadLine();
                Console.WriteLine("Enter Debit Account Number");
                debitTransaction.DebitAccountNumber = Console.ReadLine();
                Console.WriteLine("Enter the amount you want to tarnsfer");
                debitTransaction.Ammount = Convert.ToDouble(Console.ReadLine());
                creditTransaction.Ammount = debitTransaction.Ammount;
                creditTransaction.TransactionType = "credit";
                debitTransaction.TransactionType = "debit";
                debitTransaction.TransactionTime = creditTransaction.TransactionTime = DateTime.Now;
                bool CreditTransactionDone = TransactionBL.CreditTransactionBL(creditTransaction);
                bool DebitTransactionDone = TransactionBL.DebitTransactionBL(debitTransaction);
                if (DebitTransactionDone)
                {
                    if (CreditTransactionDone)
                        Console.WriteLine("Transaction Succesfull");
                    else
                    {
                        Console.WriteLine("Transaction not Successful");
                    }
                }


            }
            void GenerateReport()
            {
                Console.WriteLine("Select the service you want");
                Console.WriteLine("\n 1. Transactions of a date");
                Console.WriteLine("\n 2. Transactions of a particuar account");
                Console.WriteLine("\n 3. Transaction by Transaction Type");
                int reportChoice= Convert.ToInt32(Console.ReadLine());
                switch (reportChoice)
                {
                    case 1:
                        Console.WriteLine("Enter Transacion Date");
                        DateTime time = Convert.ToDateTime(Console.ReadLine());
                        List<Transaction> transactionList = TransactionBL.GetAllTransactionByTimeBL(time);
                        foreach (Transaction item in transactionList)
                        {
                            Console.WriteLine(item.CreditAccountNumber + "\t" + item.DebitAccountNumber + "\t" + item.Ammount + "\t" + item.Ammount + "\t" + item.TransactionType);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter Account Number");
                        string acc = Console.ReadLine();
                        List<Transaction> transactionAccList = TransactionBL.GetAllTransactionByAccountNumberBL(acc);
                        foreach (Transaction item in transactionAccList)
                        {
                            Console.WriteLine(item.CreditAccountNumber + "\t" + item.DebitAccountNumber + "\t" + item.Ammount + "\t" + item.Ammount + "\t" + item.TransactionType);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter Transacion type");
                        string type = Console.ReadLine();
                        List<Transaction> transactionTypeList = TransactionBL.GetAllTransactionByTransactionTypeBL(type);
                        foreach (Transaction item in transactionTypeList)
                        {
                            Console.WriteLine(item.CreditAccountNumber +"\t"+  item.DebitAccountNumber + "\t" + item.Ammount + "\t" + item.Ammount + "\t" + item.TransactionTime);
                        }
                        break;
                }

                
            }
/*<<<<<<< HEAD


=======*/
            void CustomerService()
            {
                int option;
                do
                {
                    CustomerMenu();
                    Console.WriteLine("Enter your Choice:\n ");
                    option = Convert.ToInt32(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                            AddCustomer();
                            break;
                        case 2:
                            ListAllCustomers();
                            break;
                        case 3:
                            SearchCustomerByID();
                            break;
                        case 4:
                            UpdateCustomer();
                            break;

                        case 5:
                            return;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (option != -1);
            }

            void CustomerMenu()
            {
                Console.WriteLine("\n***********Customer Menu***********");
                Console.WriteLine("1. Add customer");
                Console.WriteLine("2. List All customers");
                Console.WriteLine("3. Search customer by ID");
                Console.WriteLine("4. Update customer");
                Console.WriteLine("5. Exit");

                Console.WriteLine("******************************************\n");

            }


            void UpdateCustomer()
            {
                try
                {
                    int updateCustomerID;
                    Console.WriteLine("Enter Customer ID to Update Details:");
                    updateCustomerID = Convert.ToInt32(Console.ReadLine());
                    Customer updateCustomer = CustomerBL.SearchCustomerBL(updateCustomerID);
                    if (updateCustomer != null)
                    {
                        Console.WriteLine("Update Customer Name :");
                        updateCustomer.CustomerName = Console.ReadLine();
                        Console.WriteLine("Update PhoneNumber :");
                        updateCustomer.CustomerContactNumber = Console.ReadLine();
                        bool customerUpdated = CustomerBL.UpdateCustomerBL(updateCustomer);
                        if (customerUpdated)
                            Console.WriteLine("Customer Details Updated");
                        else
                            Console.WriteLine("Customer Details not Updated ");
                    }
                    else
                    {
                        Console.WriteLine("No customer Details Available");
                    }


                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

             void SearchCustomerByID()
            {
                try
                {
                    int searchCustomer_ID;
                    Console.WriteLine("Enter Customer ID to Search:");
                    searchCustomer_ID = Convert.ToInt32(Console.ReadLine());
                    Customer searchCustomerID = CustomerBL.SearchCustomerBL(searchCustomer_ID);
                    if (searchCustomerID != null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("Customer ID\t\tName\t\tPhoneNumber");
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", searchCustomerID.CustomerID, searchCustomerID.CustomerName, searchCustomerID.CustomerContactNumber);
                        Console.WriteLine("******************************************************************************");
                    }
                    else
                    {
                        Console.WriteLine("No Customer Details Available");
                    }

                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


             void ListAllCustomers()
            {
                try
                {
                    List<Customer> customerList = CustomerBL.GetAllCustomersBL();
                    if (customerList != null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("Customer ID\t\tName\t\tPhoneNumber");
                        Console.WriteLine("******************************************************************************");
                        foreach (Customer customer in customerList)
                        {
                            Console.WriteLine("{0}\t\t{1}\t\t{2}", customer.CustomerID, customer.CustomerName, customer.CustomerContactNumber);
                        }
                        Console.WriteLine("******************************************************************************");

                    }
                    else
                    {
                        Console.WriteLine("No account Details Available");
                    }
                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

             void AddCustomer()
            {
                try
                {
                    Customer newCustomer = new Customer();

                    Console.WriteLine("Enter Customer ID :");
                    newCustomer.CustomerID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Customer Name :");
                    newCustomer.CustomerName = Console.ReadLine();
                    Console.WriteLine("Enter PhoneNumber :");
                    newCustomer.CustomerContactNumber = Console.ReadLine();
                    Console.WriteLine("Enter Customer Address:");
                    newCustomer.CustomerAddress = Console.ReadLine();
                    Console.WriteLine("Enter Customer Email ID:");
                    newCustomer.CustomerEmailID = Console.ReadLine();
                    Console.WriteLine("Enter Customer PAN no :");
                    newCustomer.CustomerPANno = Console.ReadLine();
                    Console.WriteLine("Enter Customer Aadhar no. :");
                    newCustomer.CustomerAadharno = Convert.ToInt64(Console.ReadLine());
                    Console.WriteLine("Enter Customer DOB :");
                    newCustomer.CustomerDOB = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Enter Customer Gender :");
                    newCustomer.CustomerGender = 
                       Convert.ToChar(Console.ReadLine());

                    bool customerCreated = CustomerBL.CreateCustomerBL(newCustomer);
                    if (customerCreated)
                        Console.WriteLine("Customer Added");
                    else
                        Console.WriteLine("Customer not Added");
                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

//Accounts Services
             void AccountsService()
            {
                int option;
                do
                {
                    AccountsMenu();
                    Console.WriteLine("Enter your Choice:\n ");
                    option = Convert.ToInt32(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                            CreateAccount();
                            break;
                        case 2:
                            UpdateAccount();
                            break;
                        case 3:
                            DeleteAccount();
                            break;
                        case 4:
                            SearchAccount();
                            break;
                        case 5:
                            ListAllAccounts();
                            break;
                        case 6:
                            return;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (option != -1);
            }

            void AccountsMenu()
            {
                Console.WriteLine("\n***********Accounts Menu***********");
                Console.WriteLine("1. Create new account");
                Console.WriteLine("2. Update/Modify account");
                Console.WriteLine("3. Delete account");
                Console.WriteLine("4. Search account");
                Console.WriteLine("5. List all accounts");
                Console.WriteLine("6. Exit");

                Console.WriteLine("******************************************\n");

            }

            //Creating an account 
            void CreateAccount()
            {
                try
                {
                    Console.WriteLine("Enter 1 for existing customer\n");
                    Console.WriteLine("Enter 2 for new customer\n");
                    int ch = Convert.ToInt32(Console.ReadLine());

                    //When the customer already exists
                    if (ch == 1)
                    {
                        NewAccount();

                    }

                    //When the customer is a new customer
                    if (choice == 2)
                    {
                        Console.WriteLine("Enter Customer Details :");
                        AddCustomer();
                        NewAccount();
                    }

                }

                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            void NewAccount()
            {

                Console.WriteLine("Enter Customer ID :");
                int searchCustomer_ID = Convert.ToInt32(Console.ReadLine());
                Customer customer = CustomerBL.SearchCustomerBL(searchCustomer_ID);
                if (customer != null)
                {

                    Account account = new Account();
                    Console.WriteLine("Select the type of account(Savings, Current or Fixed) :");
                    account.AccountType = Console.ReadLine();
                    account.aCustomerName = customer.CustomerName;
                    account.aCustomerID = Convert.ToString(customer.CustomerID);
                    account.AccountNo = Convert.ToString(Account.Startaccno);
                    Account.Startaccno++;
                    Console.WriteLine("Enter the balance :");
                    account.Balance = Double.Parse(Console.ReadLine());
                    account.StartDate = Convert.ToDateTime(DateTime.Now);
                    Console.WriteLine("Enter the branch name :");
                    account.Branch = Console.ReadLine();
                    account.Status = "Active";


                    String acctype = account.AccountType;
                    switch (acctype)
                    {
                        case "Savings":

                            account.MinimumBalance = 0;
                            account.InterestRate = 5;
                            account.Tenure = 0;
                            break;

                        case "Current":

                            account.MinimumBalance = 500;
                            account.InterestRate = 5;
                            account.Tenure = 0;
                            break;

                        case "Fixed":

                            account.MinimumBalance = 0;
                            account.InterestRate = 5;
                            Console.WriteLine("Enter the tenure in years :");
                            account.Tenure = Double.Parse(Console.ReadLine());
                            break;
                    }

                    bool accountCreated = AccountBL.CreateAccountBL(account);
                    if (accountCreated)
                        Console.WriteLine("Account created");
                    else
                        Console.WriteLine("Account not created");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }
            }

            //Update Account
            void UpdateAccount()
             {
                try
                {
                    Console.WriteLine("Enter 1 for updating branch \n");
                    Console.WriteLine("Enter 2 for modifying account type \n");
                    int cha = Convert.ToInt32(Console.ReadLine());
                    switch (cha)
                    {
                        case 1:

                            Console.WriteLine("Enter the account number :\n");
                            string accno = Console.ReadLine();
                            Account account = AccountBL.SearchAccountBL(accno);
                            if (account != null)
                            {
                                Console.WriteLine("Enter the new account branch :\n");
                                string branch = Console.ReadLine();
                                account.Branch = branch;
                                bool accountBranchUpdated = AccountBL.UpdateBranchBL(accno, branch);
                                if (accountBranchUpdated)
                                    Console.WriteLine("Home branch updated");
                                else
                                    Console.WriteLine("Home branch not Updated ");
                            }

                            else
                            {
                                Console.WriteLine("No customer Details Available");
                            }

                            break;

                        case 2:

                            Console.WriteLine("Enter the account number :\n");
                            string accno2 = Console.ReadLine();
                            Account account1 = AccountBL.SearchAccountBL(accno2);
                            if (account1 != null)
                            {
                                Console.WriteLine("Enter the new account type(Savings, Current or Fixed) :\n");
                                string acctype = Console.ReadLine();
                                account1.AccountType = acctype;
                                double ten;
                                if (acctype == "Fixed")
                                {
                                    Console.WriteLine("Enter the tenure in years :");
                                    ten = Double.Parse(Console.ReadLine());
                                    account1.Tenure = ten;
                                }
                                else
                                {
                                    ten = 0;
                                    account1.Tenure = ten;
                                }

                                bool accountTypeUpdated = AccountBL.UpdateAccountTypeBL(accno2, acctype, ten);
                                if (accountTypeUpdated)
                                    Console.WriteLine("Account type updated");
                                else
                                    Console.WriteLine("Account type not Updated ");
                            }

                            else
                            {
                                Console.WriteLine("No customer Details Available");
                            }

                            break;

                    }
                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            //Deleting an existing account
            void DeleteAccount()
            {
                try
                {
                  
                            Console.WriteLine("Enter the account number :\n");
                            string accno = Console.ReadLine();
                            Account account = AccountBL.SearchAccountBL(accno);
                            if (account != null)
                            {
                                
                                bool accountDeleted = AccountBL.DeleteAccountBL(accno);
                                if (accountDeleted)
                                    Console.WriteLine("Account deleted");
                                else
                                    Console.WriteLine("Account not deleted");
                            }

                            else
                            {
                                Console.WriteLine("No customer details available");
                            }

                            
                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            //Searching account based on various categories 
             void SearchAccount()
            {
                try
                {
                    Console.WriteLine("1.Search account by account number:");
                    Console.WriteLine("2.Search accounts by CustomerID:");
                    Console.WriteLine("3.Search accounts by customer name:");
                    Console.WriteLine("4.Search accounts by account type:");
                    Console.WriteLine("5.Search account by home branch:");
                    Console.WriteLine("6.Search account by date:");

                    int option = Convert.ToInt32(Console.ReadLine());
                    switch(option)
                    {
                        case 1:

                            string accno;
                            Console.WriteLine("Enter account number to search:");
                            accno = Console.ReadLine();
                            Account account1 = AccountBL.SearchAccountBL(accno);
                            if (account1 != null)
                            {
                                Console.WriteLine("******************************************************************************");
                                Console.WriteLine("Customer ID\t\tName\t\tAccount Number\t\tAccount Type\t\tBalance\t\tBranch\t\tStart Date\t\tStatus");
                                Console.WriteLine("******************************************************************************");
                                Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t", account1.aCustomerID, account1.aCustomerName, account1.AccountNo, account1.AccountType, account1.Balance, account1.Branch, account1.StartDate, account1.Status);
                                Console.WriteLine("******************************************************************************");
                            }
                            else
                            {
                                Console.WriteLine("No Customer Details Available");
                            }


                            break;

                        case 2:

                            string custID;
                            Console.WriteLine("Enter customer ID to search:");
                            custID = Console.ReadLine();                         
                            List<Account> accountsbycustID = AccountBL.GetAccountsByCustomerIDBL(custID);
                            if (accountsbycustID != null)
                            {
                               
                                Console.WriteLine("******************************************************************************");
                                Console.WriteLine("Customer ID\t\tName\t\tAccount Number\t\tAccount Type\t\tBalance\t\tBranch\t\tStart Date\t\tStatus");
                                Console.WriteLine("******************************************************************************");
                                foreach (Account account in accountsbycustID)
                                {
                                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t", account.aCustomerID, account.aCustomerName, account.AccountNo, account.AccountType, account.Balance, account.Branch, account.StartDate, account.Status);
                                }
                                Console.WriteLine("******************************************************************************");

                            }
                             
                            else
                            {
                                Console.WriteLine("No Customer Details Available");
                            }


                            break;

                        case 3:

                            string custname;
                            Console.WriteLine("Enter customer name to search:");
                            custname = Console.ReadLine();
                            List<Account> accountsbycustname = AccountBL.GetAccountsByCustomerNameBL(custname);
                            if (accountsbycustname != null)
                            {

                                Console.WriteLine("******************************************************************************");
                                Console.WriteLine("Customer ID\t\tName\t\tAccount Number\t\tAccount Type\t\tBalance\t\tBranch\t\tStart Date\t\tStatus");
                                Console.WriteLine("******************************************************************************");
                                foreach (Account account in accountsbycustname)
                                {
                                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t", account.aCustomerID, account.aCustomerName, account.AccountNo, account.AccountType, account.Balance, account.Branch, account.StartDate, account.Status);
                                }
                                Console.WriteLine("******************************************************************************");

                            }

                            else
                            {
                                Console.WriteLine("No Customer Details Available");
                            }


                            break;

                        case 4:

                            string acctype;
                            Console.WriteLine("Enter account type to search:");
                            acctype = Console.ReadLine();
                            List<Account> accountsbyacctype = AccountBL.GetAccountsByTypeBL(acctype);
                            if (accountsbyacctype != null)
                            {

                                Console.WriteLine("******************************************************************************");
                                Console.WriteLine("Customer ID\t\tName\t\tAccount Number\t\tAccount Type\t\tBalance\t\tBranch\t\tStart Date\t\tStatus");
                                Console.WriteLine("******************************************************************************");
                                foreach (Account account in accountsbyacctype)
                                {
                                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t", account.aCustomerID, account.aCustomerName, account.AccountNo, account.AccountType, account.Balance, account.Branch, account.StartDate, account.Status);
                                }
                                Console.WriteLine("******************************************************************************");

                            }

                            else
                            {
                                Console.WriteLine("No Customer Details Available");
                            }


                            break;

                        case 5:

                            string branch;
                            Console.WriteLine("Enter home branch to search:");
                            branch = Console.ReadLine();
                            List<Account> accountsbybranch = AccountBL.GetAccountsByBranchBL(branch);
                            if (accountsbybranch != null)
                            {

                                Console.WriteLine("******************************************************************************");
                                Console.WriteLine("Customer ID\t\tName\t\tAccount Number\t\tAccount Type\t\tBalance\t\tBranch\t\tStart Date\t\tStatus");
                                Console.WriteLine("******************************************************************************");
                                foreach (Account account in accountsbybranch)
                                {
                                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t", account.aCustomerID, account.aCustomerName, account.AccountNo, account.AccountType, account.Balance, account.Branch, account.StartDate, account.Status);
                                }
                                Console.WriteLine("******************************************************************************");

                            }

                            else
                            {
                                Console.WriteLine("No Customer Details Available");
                            }


                            break;

                        case 6:

                            DateTime date1;
                            DateTime date2;
                            Console.WriteLine("Enter the range of dates to search:");
                            date1 = Convert.ToDateTime(Console.ReadLine());
                            date2 = Convert.ToDateTime(Console.ReadLine());
                            List<Account> accountsbydate = AccountBL.GetAccountsByDateBL(date1, date2);
                            if (accountsbydate != null)
                            {

                                Console.WriteLine("******************************************************************************");
                                Console.WriteLine("Customer ID\t\tName\t\tAccount Number\t\tAccount Type\t\tBalance\t\tBranch\t\tStart Date\t\tStatus");
                                Console.WriteLine("******************************************************************************");
                                foreach (Account account in accountsbydate)
                                {
                                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t", account.aCustomerID, account.aCustomerName, account.AccountNo, account.AccountType, account.Balance, account.Branch, account.StartDate, account.Status);
                                }
                                Console.WriteLine("******************************************************************************");

                            }

                            else
                            {
                                Console.WriteLine("No Customer Details Available");
                            }


                            break;
                    }
                   
                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
           
            //Listing all the accounts
             void ListAllAccounts()
            {
                try
                {
                    List<Account> accountList = AccountBL.GetAllAccountsBL();
                    if (accountList != null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("Customer ID\t\tName\t\tAccount Number\t\tAccount Type\t\tBalance\t\tBranch\t\tStart Date\t\tStatus");
                        Console.WriteLine("******************************************************************************");
                        foreach (Account account in accountList)
                        {
                            Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t", account.aCustomerID, account.aCustomerName, account.AccountNo, account.AccountType, account.Balance, account.Branch,account.StartDate,account.Status);
                        }
                        Console.WriteLine("******************************************************************************");

                    }
                    else
                    {
                        Console.WriteLine("No account details available");
                    }
                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            











            // b3267cbc3effac2135657a3022465a7eb8c56011

            void PrintMenu()
            {
                Console.WriteLine("\n***********Guest PhoneBook Menu***********");
                Console.WriteLine("1. Customer Services");
                Console.WriteLine("2. Account Services");
                Console.WriteLine("3. Transaction Service");
                Console.WriteLine("4. Loan Services");
                Console.WriteLine("5. Exit");

                Console.WriteLine("******************************************\n");

            }
        }

        
    }
}

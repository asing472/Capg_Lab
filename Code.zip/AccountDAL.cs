﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Pecunia.Entities;
using Pecunia.Exceptions;


namespace Pecunia.DataAccessLayer
{
    public class AccountDAL
    {
        //List of all accounts
        public static List<Account> AccountList = new List<Account>();

        //Creating a new account
        public bool CreateAccountDAL(Account newAccount)
        {
            bool AccountCreated = false;
            try
            {
                AccountList.Add(newAccount);
                AccountCreated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountCreated;

        }

        //List of all  accounts
        public List<Account> GetAllAccountsDAL()
        {
            return AccountList;
        }

        //searching  account by accountno
        public Account SearchAccountDAL(string searchAccountNo)
        {
            Account searchAccount = null;
            try
            {
                searchAccount = AccountList.Find(x => x.AccountNo == searchAccountNo);

            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchAccount;
        }

        //searching  accounts by customerID
        public List<Account> GetAccountsByCustomerIDDAL(string searchCustomerID)
        {
            List<Account> AccountsByCustID = new List<Account>();
            try
            {

                AccountsByCustID.AddRange(AccountList.FindAll(x => x.aCustomerID == searchCustomerID));

            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByCustID;
        }

        //searching accounts by customerName
        public List<Account> GetAccountsByCustomerNameDAL(string searchCustomerName)
        {
            List<Account> AccountsByCustomerName = new List<Account>();
            try
            {
                AccountsByCustomerName.AddRange(AccountList.FindAll(x => x.aCustomerName == searchCustomerName));

            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByCustomerName;
        }

        //searching accounts by type
        public List<Account> GetAccountsByTypeDAL(string searchAccountType)
        {
            List<Account> AccountsByType = new List<Account>();
            try
            {
                AccountsByType.AddRange(AccountList.FindAll(x => x.AccountType == searchAccountType));

            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByType;
        }

        //searching accounts by branch
        public List<Account> GetAccountsByBranchDAL(string searchBranch)
        {
            List<Account> AccountsByBranch = new List<Account>();
            try
            {
                AccountsByBranch.AddRange(AccountList.FindAll(x => x.Branch == searchBranch));

            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByBranch;
        }

        //searching accounts by date
        public List<Account> GetAccountsBydateDAL(DateTime d1,DateTime d2)
        {
            List<Account> AccountsByDate = new List<Account>();
            try
            {
                foreach(Account item in AccountList)
                {
                    if((item.StartDate.Ticks >= d1.Ticks)&&(item.StartDate.Ticks <= d2.Ticks))
                    {
                        AccountsByDate.AddRange(AccountList);
                    }
                }
                

            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByDate;
        }

        //Get Balance
        public double GetBalanceDAL(string accountNumber)
        {

            double balance = 0;

            try
            {
                //Account account = new Account();
                Account account;
                account = AccountList.Find(x => x.AccountNo == accountNumber);
                balance = account.Balance;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return balance;
        }

        //Update Balance
        public bool UpdateBalanceDAL(string accountNumber, double balance)
        {
            bool BalanceUpdated = false;

            try
            {
                //Account account = new Account();
                Account account;
                account = AccountList.Find(x => x.AccountNo == accountNumber);

                int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
                int st = int.Parse(account.StartDate.ToString("yyyyMMdd"));
                double yr = (now - st) / 10000;
                double si = (balance * account.InterestRate * yr) / 100;
                account.Balance = balance + si;
                BalanceUpdated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }

            return BalanceUpdated;
        }

        //Updating account branch
        public bool UpdateBranchDAL(string accountNumber, string branch)
        {
            bool AccountBranchUpdated = false;

            try
            {
                //Account account = new Account();
                Account account;
                account = AccountList.Find(x => x.AccountNo == accountNumber);
                account.Branch = branch;
                AccountBranchUpdated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountBranchUpdated;
        }

        //Modifying account type
        public bool UpdateAccountTypeDAL(string accountNumber, string accountType, double tenure)
        {
            bool AccountTypeUpdated = false;

            try
            {
                Account account;
                account = AccountList.Find(x => x.AccountNo == accountNumber);
                account.AccountType = accountType;
                account.Tenure = tenure;
                AccountTypeUpdated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountTypeUpdated;
        }

        //Deleting an existing account
        public bool DeleteAccountDAL(string deleteAccountNo)
        {
            bool AccountDeleted = false;

            try
            {
                Account deleteAccount = null;
                Account account;
                account = AccountList.Find(x => x.AccountNo == deleteAccountNo);
                account.Status = "Closed";
                deleteAccount = account;

                if (deleteAccountNo != null)
                {
                    //AccountList.Remove(deleteAccount);
                    AccountDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountDeleted;

        }

    }
}

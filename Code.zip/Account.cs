﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    public class Account
    {
        public static int Startaccno = 1000000000;

        public string aCustomerName { get; set; }
        public string aCustomerID { get; set; }
        public string AccountNo { get; set; }
        public double Balance { get; set; }
        public DateTime StartDate { get; set; }
        public string AccountType { get; set; }
        public string Branch { get; set; }
        public string Status { get; set; }
        public double MinimumBalance { get; set; }
        public double InterestRate { get; set; }
        public double Tenure { get; set; }


        public Account()
        {
            aCustomerID = "";
            aCustomerName = "";
            AccountType = "";
            Branch = "";
            MinimumBalance = 0;
            InterestRate = 0;
            Balance = 0;
            Tenure = 0;
            StartDate = DateTime.Now;
            Status = "Active";
            //AccountNo = Convert.ToString(Startaccno);
            //Startaccno++;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.Pecunia.Entities
{
    class AccountPolicy
    {
        public Guid AccountID { get; set; }
        public double MinimumBalance
        {
            
        set
            {
                

                if ((AccountType == "Savings")&&(age >= 60))
                {
                    value = 500;
                }

                if(AccountType == "Current")
                {
                    value = 0;
                }

                if(AccountType == "Fixed")
                {
                    value = 2000;
                }

            }

            get
            {
                return MinimumBalance;
            }
        }
        public double InterestRate
        {
            set
            {
                int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
                int dob = int.Parse(DateOfBirth.ToString("yyyyMMdd"));
                int age = (now - dob) / 10000;

                if (AccountType == "Savings")
                {
                    if(age >= 60)
                    {
                        value = 6.5;
                    }

                    else if(Gender == "Female")
                    {
                        value = 5;
                    }

                    else
                    {
                        value = 4;
                    }
                }

                if (AccountType == "Current")
                {
                    if (age >= 60)
                    {
                        value = 3;
                    }

                    else if (Gender == "Female")
                    {
                        value = 2;
                    }

                    else
                    {
                        value = 1.5;
                    }

                }

                if (AccountType == "Fixed")
                {
                    if (age >= 60)
                    {
                        value = 5;
                    }

                    else if (Gender == "Female")
                    {
                        value = 4;
                    }

                    else
                    {
                        value = 3.5;
                    }
                }

            }

            get
            {
                return InterestRate;
            }
        }
        public String AccountType { get; set; }

    }
}

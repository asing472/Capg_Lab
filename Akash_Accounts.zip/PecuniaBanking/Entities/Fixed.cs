﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.Pecunia.Entities
{
    /// <summary>
    /// Interface of Fixed Entity
    /// </summary>
    public interface IFixed
    {
        double Tenure { get; set; }
        double FDDeposit { get; set; }
    }

    /// <summary>
    /// Represents Fixed Deposit Account
    /// </summary>
    public class Fixed : IAccount, IFixed
    {
        public static int BaseAccno2 = 2000000000;
        public Guid AccountID { get; set; }
        public Guid CustomerID { get; set; }
        public string AccountNo { get; set; }
        public double CurrentBalance { get; set; }
        public DateTime DateOfAccountOpening { get; set; }
        public string AccountType { get; set; }
        public string Branch { get; set; }
        public string Status { get; set; }
        public double MinimumBalance { get; set; }
        public double InterestRate { get; set; }
        public double Tenure { get; set; }
        public double FDDeposit { get; set; }
        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public Fixed()
        {
            AccountID = default(Guid);
            CustomerID = default(Guid);
            AccountNo = null;
            CurrentBalance = 0;
            DateOfAccountOpening = DateTime.Now;
            AccountType = null;
            Branch = null;
            MinimumBalance = 0;
            InterestRate = 0;
            Status = "Active";
            Tenure = 0;
            FDDeposit = 0;
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);

        }
    }
}
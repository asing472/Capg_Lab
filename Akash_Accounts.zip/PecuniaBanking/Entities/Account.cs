﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PecuniaHelpers.ValidationAttributes;


namespace Capgemini.Pecunia.Entities
{
   
    /// <summary>
    /// Interface for Account Entity
    /// </summary>
    public interface IAccount
    {
        
        Guid AccountID { get; set; }
        Guid CustomerID { get; set; }
        string AccountNo { get; set; }
        double CurrentBalance { get; set; }
        DateTime DateOfAccountOpening { get; set; }
        string AccountType { get; set; }
        string Branch { get; set; }
        string Status { get; set; }
        double MinimumBalance { get; set; }
        double InterestRate { get; set; }
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }

    }

    /// <summary>
    /// Represents Savings and Current Account
    /// </summary>
    public class Account : IAccount
    {
        
        public static int BaseAccno1 = 1000000000;

        /*Auto-Imlemented Properties*/
        [Required("Account ID can't be blank.")]
        public Guid AccountID { get; set; }

        [Required("Customer ID can't be blank.")]
        public Guid CustomerID { get; set; }

        [Required("Account No can't be blank.")]
        public string AccountNo { get; set; }

        [Required("Current Balance can't be negative.")]
        public double CurrentBalance { get; set; }

        [Required("Date of Account Opening can't be blank.")]
        public DateTime DateOfAccountOpening { get; set; }

        [Required("Account Type can't be other than Savings or Current")]
        public string AccountType { get; set; }

        [Required("Branch can't be blank.")]
        public string Branch { get; set; }

        [Required("Status can be either Active or Closed")]
        public string Status { get; set; }

        [Required("Minimum Balance can't be negative.")]
        public double MinimumBalance { get; set; }

        [Required("Interest Rate can't be negative.")]
        public double InterestRate { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public Account()
        {
            AccountID = default(Guid);
            CustomerID = default(Guid);
            AccountNo = null;
            CurrentBalance = 0;
            DateOfAccountOpening = DateTime.Now;
            AccountType = null;
            Branch = null;
            MinimumBalance = 0;
            InterestRate = 0;
            Status = "Active";
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);
            
        }

    }
}

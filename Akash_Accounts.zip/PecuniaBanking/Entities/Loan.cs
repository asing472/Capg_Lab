﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PecuniaHelpers.ValidationAttributes;

namespace Entities
{
    public interface ILoan
    {        
        string LoanType { get; set; }
        Double AmtOfLoan { get; set; }
        string LoanStatus { get; set; }
        float Tenure { get; set; }
        double YearlyIncome { get; set; }
        double YearsOfService { get; set; }
    }
    public class Loan : ILoan, iID
    {
        public Guid ID { get; set; }
        public string LoanType { get; set; }
        public Double AmtOfLoan { get; set; }
        public string LoanStatus { get; set; }
        public float Tenure { get; set; }
        public double YearlyIncome { get; set; }
        public double YearsOfService { get; set; }

    }
    //Create Constructor for each class



    //Car Loan
    public class CarLoan : Loan
        {
        
        public string License { get; set; }
        }


        //Home Loan
        public class HomeLoan : Loan
        {
        
        public string License { get; set; }
        public double Collateral { get; set; }
        }


        //Education Loan
        public class EducationLoan : Loan
        {

        
        public double Collateral { get; set; }
        public string Sponseror { get; set; }
        public string CollegeName { get; set; }
        public string AdmissionID { get; set; }
        }


        //Personal Loan
        public class PersonalLoan : Loan
        {
        public double Collateral { get; set; }
        }
    
}

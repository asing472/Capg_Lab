﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PecuniaBusinessLayer
{
    public class BaseBL
    {
        //We will be writing validation using attributes

    }
}

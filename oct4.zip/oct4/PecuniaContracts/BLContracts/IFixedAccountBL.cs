﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    public interface IFixedAccountBL : IDisposable
    {
        Task<bool> CreateAccountBL(FixedAccount newfixed);
        Task<List<FixedAccount>> GetAllAccountsBL();
        Task<FixedAccount> GetAccountByAccountNoBL(string searchAccountNo);
        Task<List<FixedAccount>> GetAccountsByCustomerNoBL(string searchCustomerNo);
        Task<List<FixedAccount>> GetAccountsByBranchBL(string searchBranch);
        Task<List<FixedAccount>> GetAccountsByAccountOpeningDateBL(DateTime startDate, DateTime endDate);
        Task<double> GetBalanceBL(string accountNumber);
        Task<bool> UpdateBalanceBL(string accountNumber, double balance);
        Task<bool> UpdateBranchBL(string accountNumber, string branch);
        Task<bool> DeleteAccountBL(string deleteAccountNo);
    }
}

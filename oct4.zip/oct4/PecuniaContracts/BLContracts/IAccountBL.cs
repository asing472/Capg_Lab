﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    
        public interface IAccountBL : IDisposable
        {
            Task<bool> CreateAccountBL(Account newAccount);
            Task<List<Account>> GetAllAccountsBL();
            Task<Account> SearchAccountByAccountNoBL(string searchAccountNo);
            Task<List<Account>> GetAccountsByCustomerNoBL(string searchCustomerNo);
            Task<List<Account>> GetAccountsByTypeBL(string searchAccountType);
            Task<List<Account>> GetAccountsByBranchBL(string searchBranch);
            Task<List<Account>> GetAccountsByAccountOpeningDateBL(DateTime d1, DateTime d2);
            Task<double> GetBalanceBL(string accountNumber);
            Task<bool> UpdateBalanceBL(string accountNumber, double balance);
            Task<bool> UpdateBranchBL(string accountNumber, string branch);
            Task<bool> UpdateAccountTypeBL(string accountNumber, string accountType);
            Task<bool> DeleteAccountBL(string deleteAccountNo);
        }
}

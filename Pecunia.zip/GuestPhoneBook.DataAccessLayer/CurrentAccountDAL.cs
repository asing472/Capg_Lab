﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Pecunia.Entities;
using Pecunia.Exceptions;

namespace Pecunia.DataAccessLayer
{
    public class CurrentAccountDAL
    {
        public static List<CurrentAccount> accountList = new List<CurrentAccount>();

        public bool CreateAccountDAL(CurrentAccount newAccount)
        {
            bool accountCreated = false;
            try
            {
                accountList.Add(newAccount);
                accountCreated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountCreated;

        }

        public List<CurrentAccount> GetAllAccountsDAL()
        {
            return accountList;
        }

        public CurrentAccount SearchAccountDAL(string searchAccountNo)
        {
            CurrentAccount searchAccount = null;
            try
            {
                foreach (CurrentAccount item in accountList)
                {
                    if (item.AccountNo == searchAccountNo)
                    {
                        searchAccount = item;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchAccount;
        }

        //searching accounts by customerID
        public List<CurrentAccount> GetAccountsByCustomerIDDAL(string searchcustomerID)
        {
            List<CurrentAccount> accountsbyCustID = new List<CurrentAccount>();
            try
            {
                foreach (CurrentAccount item in accountList)
                {
                    if (item.CustomerID == searchcustomerID)
                    {
                        accountsbyCustID.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountsbyCustID;
        }

        //Updating or modifying account details
        public bool UpdateAccountDAL(CurrentAccount updateAccount)
        {
            bool accountUpdated = false;
            try
            {
                for (int i = 0; i < accountList.Count; i++)
                {
                    if (accountList[i].AccountNo == updateAccount.AccountNo)
                    {
                        updateAccount.CustomerName = accountList[i].CustomerName;
                        updateAccount.Phone = accountList[i].Phone;
                        updateAccount.EmailID = accountList[i].EmailID;
                        updateAccount.Address = accountList[i].Address;
                        updateAccount.AccountType = accountList[i].AccountType;
                        updateAccount.MinimumBalance = accountList[i].MinimumBalance;
                        updateAccount.InterestRate = accountList[i].InterestRate;
                        accountUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountUpdated;

        }

        public bool DeleteAccountDAL(string deleteAccountNo)
        {
            bool accountDeleted = false;
            try
            {
                CurrentAccount deleteAccount = null;
                foreach (CurrentAccount item in accountList)
                {
                    if (item.AccountNo == deleteAccountNo)
                    {
                        deleteAccount = item;
                    }
                }

                if (deleteAccountNo != null)
                {
                    accountList.Remove(deleteAccount);
                    accountDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountDeleted;

        }

    }
}

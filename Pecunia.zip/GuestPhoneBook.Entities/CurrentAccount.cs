﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    public class CurrentAccount
    {

        private string customerID;
        private string accountno;
        private double balance;
        private DateTime startDate;
        private string accountType;
        private double minimumBalance;
        private double interestRate;
        private string branch;

        public string CustomerID
        {
            get => customerID;
            set => customerID = value;
        }

        public string AccountNo
        {
            get => accountno;
            set => accountno = value;
        }
        public double Balance
        {
            get => balance;
            set => balance = value;
        }
        public DateTime StartDate
        {
            get => startDate;
            set => startDate = value;
        }
        public string AccountType
        {
            get => accountType;
            set => accountType = value;
        }
        public double MinimumBalance
        {
            get => minimumBalance;
            set => minimumBalance = value;
        }
        public double InterestRate
        {
            get => interestRate;
            set => interestRate = value;
        }

        public string Branch
        {
            get => branch;
            set => branch = value;
        }

        public CurrentAccount()
        {
            CustomerID = "";
            AccountType = "Current";
            MinimumBalance = 500;
            InterestRate = 6;
            Branch = "";
            AccountNo = "";
            Balance = 0;
            StartDate = DateTime.Now;
           
        }
    }
}

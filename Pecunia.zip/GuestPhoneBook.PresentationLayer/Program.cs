﻿using System;
using System.Collections.Generic;
using System.Text;
using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Exceptions;

namespace Pecunia.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddAccount();
                        break;
                    case 2:
                        ListAllAccounts();
                        break;
                    case 3:
                        SearchAccountByID();
                        break;
                    case 4:
                        UpdateAccount();
                        break;
                    case 5:
                        DeleteAccount();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }

        private static void DeleteAccount()
        {
            try
            {
                int deleteAccountID;
                Console.WriteLine("Enter AccountID to Delete:");
                deleteAccountID = Convert.ToInt32(Console.ReadLine());
                CurrentAccount deleteAccount = CurrentAccountBL.SearchAccountBL(deleteAccountID);
                if (deleteAccount != null)
                {
                    bool Accountdeleted = CurrentAccountBL.DeleteAccountBL(deleteAccountID);
                    if (Accountdeleted)
                        Console.WriteLine("account Deleted");
                    else
                        Console.WriteLine("account not Deleted ");     
                }
                else
                {
                    Console.WriteLine("No account Details Available");
                }


            }
            catch (PecuniaException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateAccount()
        {
            try
            {
                int updateAccountID;
                Console.WriteLine("Enter AccountID to Update Details:");
                updateAccountID = Convert.ToInt32(Console.ReadLine());
                CurrentAccount updatedAccount = CurrentAccountBL.SearchAccountBL(updateAccountID);
                if (updatedAccount != null)
                {
                    Console.WriteLine("Update account Name :");
                    updatedAccount.AccountName = Console.ReadLine();
                    Console.WriteLine("Update PhoneNumber :");
                    updatedAccount.AccountContactNumber = Console.ReadLine();
                    bool AccountUpdated = CurrentAccountBL.UpdateAccountBL(updatedAccount);
                    if (AccountUpdated)
                        Console.WriteLine("account Details Updated");
                    else
                        Console.WriteLine("account Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No account Details Available");
                }
               

            }
            catch (PecuniaException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchAccountByID()
        {
            try
            {
                int searchAccountID;
                Console.WriteLine("Enter AccountID to Search:");
                searchAccountID = Convert.ToInt32(Console.ReadLine());
                CurrentAccount searchAccount = CurrentAccountBL.SearchAccountBL(searchAccountID);
                if (searchAccount != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("AccountID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchAccount.AccountID, searchAccount.AccountName, searchAccount.AccountContactNumber);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No account Details Available");
                }

            }
            catch (PecuniaException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void ListAllAccounts()
        {
            try
            {
                List<CurrentAccount> accountList = CurrentAccountBL.GetAllAccountsBL();
                if (accountList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("AccountID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    foreach (CurrentAccount account in accountList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", account.AccountID, account.AccountName, account.AccountContactNumber);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No account Details Available");
                }
            }
            catch (PecuniaException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddAccount()
        {
            try
            {
                CurrentAccount newAccount = new CurrentAccount();
                Console.WriteLine("Enter AccountID :");
                newAccount.AccountID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter account Name :");
                newAccount.AccountName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newAccount.AccountContactNumber = Console.ReadLine();
                bool accountCreated = CurrentAccountBL.AddAccountBL(newAccount);
                if (accountCreated)
                    Console.WriteLine("account Added");
                else
                    Console.WriteLine("account not Added");
            }
            catch (PecuniaException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n***********account PhoneBook Menu***********");
            Console.WriteLine("1. Add account");
            Console.WriteLine("2. List All Accounts");
            Console.WriteLine("3. Search account by ID");
            Console.WriteLine("4. Update account");
            Console.WriteLine("5. Delete account");
            Console.WriteLine("6. Exit");
            Console.WriteLine("******************************************\n");

        }
    }
}

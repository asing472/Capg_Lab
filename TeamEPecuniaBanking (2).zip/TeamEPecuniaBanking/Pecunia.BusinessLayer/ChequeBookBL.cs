﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cheque.DataAccessLayer;
using Cheque.Entities;
using Pecunia.Exceptions;

namespace Cheque.BusinessLayer
{
    public class ChequeBookBL
    {
        private static bool ValidateChequeBook(ChequeBook chequebook)
        {
            StringBuilder sb = new StringBuilder();
            bool validchequebookrequest = true;

            if (chequebook.NumberOfLeaves % 5 != 0)
            {
                validchequebookrequest = false;
                sb.Append(Environment.NewLine + "Enter valid number of pages");

            }
            if (chequebook.ChequeBookStatus != "Requested" && chequebook.ChequeBookStatus != "Approved")
            {
                validchequebookrequest = false;
                sb.Append(Environment.NewLine + "Cheque status should be Requested or Approved ");
            }
            if (validchequebookrequest == false)
            {
                throw new PecuniaException(sb.ToString());
            }
            return validchequebookrequest;
        }

        public static bool ChequeBookRequestBL(ChequeBook chequebook)
        {
            bool chequeBookRequested = false;
            try
            {
                if (ValidateChequeBook(chequebook))
                {
                    ChequeBookDAL chequebookDAL = new ChequeBookDAL();
                    chequeBookRequested = chequebookDAL.ChequeBookRequestDAL(chequebook);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return chequeBookRequested;
        }
        public static List<ChequeBook> GetAllRequestedChequeBookListBL()
        {
            List<ChequeBook> requestedChequeList = null;
            try
            {
                ChequeBookDAL chequebookDAL = new ChequeBookDAL();
                requestedChequeList = chequebookDAL.GetAllRequestedChequeBookListDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return requestedChequeList;
        }
        public static bool ChequeBookApprovedBL(string deletechequebookId)
        {
            bool chequeBookApproved = false;
            try
            {
                if (deletechequebookId != null)
                {
                    ChequeBookDAL chequebookDAL = new ChequeBookDAL();
                    chequeBookApproved = chequebookDAL.ChequeBookApprovedDAL(deletechequebookId);
                }
                else
                {
                    throw new PecuniaException("Invalid ChequeId");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return chequeBookApproved;
        }
        public static List<ChequeBook> GetAllApprovedChequeBookListBL()
        {
            List<ChequeBook> approvedChequeList = null;
            try
            {
                ChequeBookDAL chequebookDAL = new ChequeBookDAL();
                approvedChequeList = chequebookDAL.GetAllApprovedChequeBookListDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return approvedChequeList;
        }
    }
}

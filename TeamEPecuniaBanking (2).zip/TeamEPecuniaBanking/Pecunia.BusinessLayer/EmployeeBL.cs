﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;
using Pecunia.Exceptions;

namespace Pecunia.BusinessLayer
{
    public class EmployeeBL
    {
        private static bool ValidateEmployee(Employee employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
            if (employee.EmployeeID <= 0)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Invalid Employee ID");

            }
            if (employee.EmployeeName == string.Empty && !ValidateName(employee.EmployeeName))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Name Required");

            }
            if (employee.EmployeeEmail == string.Empty && !ValidateEmail(employee.EmployeeEmail))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Email not correct");
            }
            if (employee.EmployeePassword == string.Empty && !ValidatePassword(employee.EmployeePassword))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Password Invalid");
            }
             if(validEmployee == false)
                System.Console.WriteLine(sb.ToString());
            return validEmployee;
        }

        private static bool ValidateName(string name)
        {

            Regex reg = new Regex(" ^[a - zA - Z] * $");
            bool check = reg.IsMatch(name);
            return check;
        }
        private static bool ValidateEmail(string email)
        {

            Regex reg = new Regex(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
            bool check = reg.IsMatch(email);
            return check;
        }
        private static bool ValidatePassword(string password)
        {

            Regex hasNumber = new Regex(@"[0-9]+");
            Regex hasUpperChar = new Regex(@"[A-Z]+");
            Regex hasMinimum8Chars = new Regex(@".{8,}");
            bool check = hasNumber.IsMatch(password) && hasUpperChar.IsMatch(password) && hasMinimum8Chars.IsMatch(password);
            return check;
        }


        public static bool AddEmployeeBL(Employee newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateEmployee(newEmployee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeAdded = employeeDAL.AddEmployeeDAL(newEmployee);

                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
           

            return employeeAdded;
        }

        public static List<Employee> GetAllEmployeeBL()
        {
            List<Employee> employeeList = null;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                employeeList = employeeDAL.GetAllEmployeesDAL();
            }
            
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return employeeList;
        }

        public static Employee GetEmployeeByEmplyeeIdBL(int searchEmployeeID)
        {
            Employee searchEmployee = null;
            try
            {
                EmployeeDAL EmployeeDAL = new EmployeeDAL();
                searchEmployee = EmployeeDAL.GetEmployeeByEmplyeeIdDAL(searchEmployeeID);
            }
            
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchEmployee;

        }

        public static Employee GetEmployeeByEmplyeeNameBL(string searchEmployeeName)
        {
            Employee searchEmployee = null;
            try
            {
                EmployeeDAL EmployeeDAL = new EmployeeDAL();
                searchEmployee = EmployeeDAL.GetEmployeeByEmplyeeNameDAL(searchEmployeeName);
            }
            
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchEmployee;

        }

        public bool GetEmplyeeByIDandPasswordBL(int checkEmployeeId, string checkEmployeePassword)
        {
            bool checkEmployee = false;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                checkEmployee = employeeDAL.GetEmplyeeByIDandPassworDAl(checkEmployeeId, checkEmployeePassword);
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }

            return checkEmployee;

        }

        public static bool UpdateEmployeeBL(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                if (ValidateEmployee(updateEmployee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeUpdated = employeeDAL.UpdateEmployeeDAL(updateEmployee);
                }
            }
            
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }

            return employeeUpdated;
        }
        public static bool DeleteEmployeeBL(int deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                if (deleteEmployeeID > 0)
                {
                    EmployeeDAL guestDAL = new EmployeeDAL();
                    employeeDeleted = guestDAL.DeleteEmployeetDAL(deleteEmployeeID);
                }

                else
                {
                    throw new PecuniaException("Invalid Guest ID");
                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            
            return employeeDeleted;
        }

    }
}

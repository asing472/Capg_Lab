﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.DataAccessLayer;
using Pecunia.Entities;
using Pecunia.Exceptions;
namespace Pecunia.BusinessLayer
{
    public class TransactionBL
    {
        public static bool ValidateTransaction(Transaction transaction)
        {
            bool validate = true;
            //foreach (Account acc in accountList)
            //{
            //    if (!((acc.AccountNumber == transaction.DebitAccountNumber|| transaction.DebitAccountNumber ==null) && (acc.AccountNumber== transaction.CreditAccountNumber) ||transaction.CreditAccountNumber == null))
            //    {
            //        validate = false;
            //    }
            //}
            
            if(transaction.Ammount < 0)
            {
                validate = true;
            }
            return validate;
        }
        public static bool DebitTransactionBL(Transaction newTransaction)
        {
           
            bool transactionDone = false;
            try
            {
                if (ValidateTransaction(newTransaction))
                {
                    TransactionDAL transactionDal = new TransactionDAL();
                    transactionDone = transactionDal.DebitTransactionDAL(newTransaction);
                }
            }
            catch(Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionDone;
        }

        public static bool CreditTransactionBL(Transaction newTransaction)
        {
            bool transactionDone = false;
            try
            {
                if (ValidateTransaction(newTransaction))
                {
                    TransactionDAL transactionDal = new TransactionDAL();
                    transactionDone = transactionDal.CreditTransactionDAL(newTransaction);
                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionDone;
        }

        public bool AccountTransferBL(Transaction newTransaction)
        {
            bool transactionDone = false;
            try
            {
                if (ValidateTransaction(newTransaction))
                {
                    TransactionDAL transactionDal = new TransactionDAL();
                    transactionDone = transactionDal.AccountTransferDAL(newTransaction);
                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionDone;
        }

        public List<Transaction> GetAllTransactionBL()
        {
            List<Transaction> transactionList = null;
            try
            {
                TransactionDAL transactionDAL = new TransactionDAL();
                transactionList = transactionDAL.GetAllTransactionDAL();
            }
            //catch (GuestPhoneBookException ex)
            //{
            //    throw ex;
            //}
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionList;
        }

        public static  List<Transaction> GetAllTransactionByTransactionTypeBL(string transactionType)
        {
            List<Transaction> transactionList = null;
            try
            {
                TransactionDAL transactionDAL = new TransactionDAL();
                transactionList = transactionDAL.GetAllTransactionByTransactionTypeDAL( transactionType);
            }
            //catch (GuestPhoneBookException ex)
            //{
            //    throw ex;
            //}
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionList;
        }

        public static  List<Transaction> GetAllTransactionByAccountNumberBL(string accountNumber)
        {
            List<Transaction> transactionList = null;
            try
            {
                TransactionDAL transactionDAL = new TransactionDAL();
                transactionList = transactionDAL.GetAllTransactionByAccountNumberDAL(accountNumber);
            }
            //catch (GuestPhoneBookException ex)
            //{
            //    throw ex;
            //}
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionList;
        }
        public static List<Transaction> GetAllTransactionByTimeBL(DateTime transactionTime)
        {
            List<Transaction> transactionList = null;
            try
            {
                TransactionDAL transactionDAL = new TransactionDAL();
                //transactionList = transactionDAL.GetAllTransactionByTimeDAL(accountNumber);
            }
            //catch (GuestPhoneBookException ex)
            //{
            //    throw ex;
            //}
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionList;
        }
    }
}
 
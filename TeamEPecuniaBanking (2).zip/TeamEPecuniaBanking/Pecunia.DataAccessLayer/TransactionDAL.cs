﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
namespace Pecunia.DataAccessLayer
{
    public class TransactionDAL
    {
        public static List<Transaction> transactionList = new List<Transaction>();

        public bool DebitTransactionDAL(Transaction newTransaction)
        {
            bool transactionDone = false;
            try
            {
                //Account account = new Account();
                //double Bal = account.Getbalance();
                //Bal = Bal - ammount;
                //account.UpdateBalance();
                transactionList.Add(newTransaction);
                transactionDone = true;

            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionDone;
        }

        public bool CreditTransactionDAL(Transaction newTransaction)
        {
            bool transactionDone = false;
            try
            {
                //Account account = new Account();
                //double Bal = account.Getbalance();
                //Bal = Bal + ammount;
                //account.UpdateBalance();
                transactionList.Add(newTransaction);
                transactionDone = true;

            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionDone;
        }

        public bool AccountTransferDAL(Transaction newTransaction)
        {
            bool transactionDone = false;
            try
            {
                //Account account = new Account();
                //double debitAccountBalance = account.Getbalance(Transaction.DebitAccountNumber);
                //double creditAccountBalance = account.Getbalance(Transaction.CreditAccountNumber);
                //debitAccountbalance -= ammount;
                //creditAccountBalance += amount;
                //account.UpdateBalance(accNumber, balance);
                transactionList.Add(newTransaction);
                transactionDone = true;

            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return transactionDone;
        }

        public List<Transaction> GetAllTransactionDAL()
        {
            return transactionList;
        }

        public List<Transaction> GetAllTransactionByTransactionTypeDAL(string transactionType)
        {
            List<Transaction> searchTransaction = new List<Transaction>();

            try
            {
                foreach (Transaction item in transactionList)
                {
                    if (item.TransactionType == transactionType)
                    {
                        searchTransaction.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchTransaction;


        }

        public List<Transaction> GetAllTransactionByAccountNumberDAL(string accountNumber)
        {
            List<Transaction> searchTransaction = new List<Transaction>();

            try
            {
                foreach (Transaction item in transactionList)
                {
                    if (item.DebitAccountNumber == accountNumber || item.CreditAccountNumber == accountNumber)
                    {
                        searchTransaction.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchTransaction;


        }
        public List<Transaction> GetAllTransactionByTimeDAL(DateTime transactionTime)
        {
            List<Transaction> searchTransaction = new List<Transaction>();

            try
            {
                foreach (Transaction item in transactionList)
                {
                    if (item.TransactionTime == transactionTime)
                    {
                        searchTransaction.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchTransaction;


        }




    }
}

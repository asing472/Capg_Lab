﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Creditcard.Entities;
using Pecunia.Exceptions;

namespace Creditcard.DataAccessLayer
{
    public class CreditCardDAL
    {
        public static List<CreditCard> creditCardList = new List<CreditCard>();
        public static List<CreditCard> blockedCreditCardList = new List<CreditCard>();
        public bool NewCreditCardIssueDAL(CreditCard creditCard)
        {
            bool creditCardIssued = false;
            try
            {
                creditCard.CardStatus = "Issued";
                creditCardList.Add(creditCard);
                creditCardIssued = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return creditCardIssued;

        }

        public List<CreditCard> GetCreditCardListDAL()
        {
            return creditCardList;
        }
        public bool UpdateCreditCardStatusDAL(string accountNo)
        {
            bool creditCardBlocked = false;
            try
            {
                CreditCard creditCard = null;
                foreach (CreditCard item in creditCardList)
                {
                    if (item.AccountNo == accountNo)
                    {
                        creditCard = item;
                    }
                }

                if (creditCard != null)
                {
                    creditCardList.Remove(creditCard);
                    creditCard.CardStatus = "Blocked";
                    blockedCreditCardList.Add(creditCard);
                    creditCardBlocked = true;
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return creditCardBlocked;
        }
        public List<CreditCard> GetBlockedCreditCardListDAL()
        {
            return blockedCreditCardList;
        }


    }
}

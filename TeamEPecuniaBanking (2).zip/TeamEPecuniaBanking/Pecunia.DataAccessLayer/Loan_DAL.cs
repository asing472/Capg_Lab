﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Loan_Entities;
using Pecunia.Exceptions;

namespace Pecunia.DataAccessLayer

{
    public class Loan_DAL
    {
        public class CarLoanServices
        {
            //Loan List
            public static List<CarLoan> carList = new List<CarLoan>();//doubt always same list will be appended in case we go out of class during 1 console use

            public bool carloan(CarLoan car)
            {
                bool CarAdded = false;
                try
                { // we have to write  get license here ?
                    carList.Add(car);
                    CarAdded = true;
                }
                catch (SystemException ex)
                {
                    throw new PecuniaException(ex.Message);
                }
                return CarAdded;

            }

            public List<CarLoan> showlist()
            {
                return carList;
            }
        }
        public class HomeLoanServices
        {
            //Loan List
            public static List<HomeLoan> homelist = new List<HomeLoan>();


            public bool homeloan(HomeLoan home)
            {
                bool homeeAdded = false;
                try
                {
                    homelist.Add(home);
                    homeeAdded = true;
                }
                catch (SystemException ex)
                {
                    throw new PecuniaException(ex.Message);
                }
                return homeeAdded;

            }
            public List<HomeLoan> hshowlist()
            {
                return homelist;
            }

        }
        public class EduLoanServices
        {
            //Loan List
            public static List<EducationLoan> EduList = new List<EducationLoan>();

            public bool EduLoan(EducationLoan Edloan)
            {
                bool edadded = false;
                try
                {
                    EduList.Add(Edloan);
                    edadded = true;
                }
                catch (SystemException ex)
                {
                    throw new PecuniaException(ex.Message);
                }
                return edadded;

            }
            public List<EducationLoan> Eshowlist()
            {
                return EduList;
            }
        }
        public class PerLoanServices
        {
            //Loan List
            public static List<PersonalLoan> PersonalList = new List<PersonalLoan>();

            public bool Perloan(PersonalLoan Ploan)
            {
                bool peradded = false;
                try
                {
                    PersonalList.Add(Ploan);
                    peradded = true;
                }
                catch (SystemException ex)
                {
                    throw new PecuniaException(ex.Message);
                }
                return peradded;

            }
            public List<PersonalLoan> Pshowlist()
            {
                return PersonalList;
            }
        }

        public class LoanServices
        {
            //Loan List
            public static List<Loan> LoanList = new List<Loan>();

            //Apply Loan
            public bool new_loan(Loan L)
            {


                bool LoanAdded = false;

                try
                {
                    LoanList.Add(L);

                }
                catch (SystemException ex)
                {
                    throw new PecuniaException(ex.Message); //pecunia xception class will be linked
                }


                switch (L.Loan_type)
                {
                    case "Car":
                        {
                            //Link car loan with loan

                            CarLoanServices c1 = new CarLoanServices();

                            CarLoan c = new CarLoan();


                            c1.carloan(c);
                            c.Loan_Amt = L.Loan_Amt;
                            c.Tenure = L.Tenure;

                            LoanAdded = true;
                            break;
                        }
                    case "Home":
                        {
                            //Link home loan with loan
                            HomeLoanServices c2 = new HomeLoanServices();
                            HomeLoan H = new HomeLoan();
                            c2.homeloan(H);
                            LoanAdded = true;
                            break;
                        }
                    case "Educational":
                        {
                            //Link Educational loan with loan
                            EduLoanServices c3 = new EduLoanServices();
                            EducationLoan E = new EducationLoan();
                            c3.EduLoan(E);
                            LoanAdded = true;
                            break;
                        }
                    case "Personal":
                        {
                            //Link personal loan with loan
                            PerLoanServices p = new PerLoanServices();
                            PersonalLoan perl = new PersonalLoan();
                            p.Perloan(perl);
                            LoanAdded = true;
                            break;
                        }
                }

                return LoanAdded;
            }

            //Loan Update
            public void update_loan(string LID, string field)
            {
                foreach (Loan l in LoanList)
                {
                    if (l.loan_ID == LID)
                    {
                        switch (LID)
                        {
                            case "amt":
                                {
                                    l.Loan_Amt = double.Parse(Console.ReadLine());
                                    break;
                                }
                            case "Status":
                                {
                                    l.Loan_Status = Console.ReadLine();
                                    break;
                                }
                            case "Tenure":
                                {
                                    l.Tenure = float.Parse(Console.ReadLine());
                                    break;
                                }
                            case "Income":
                                {
                                    l.YearlyIncome = double.Parse(Console.ReadLine());
                                    break;
                                }
                            case "Years":
                                {
                                    l.Years_of_service = double.Parse(Console.ReadLine());
                                    break;
                                }

                        }

                    }
                }
            }


            //Loan By Status single function 
            public List<Loan> loan_By_status(string LT)
            {
                List<Loan> statuslist = new List<Loan>();


                switch (LT)
                {
                    case "Approved":
                        {
                            foreach (Loan l in LoanList)
                                if (l.Loan_Status == "Approved")
                                {
                                    statuslist.Add(l);
                                }
                            break;
                        }
                    case "Rejected":
                        {
                            //Link home loan with loan
                            foreach (Loan l in LoanList)
                                if (l.Loan_Status == "Rejected")
                                {
                                    statuslist.Add(l);
                                }
                            break;
                        }
                    case "InProgress":
                        {
                            foreach (Loan l in LoanList)
                                if (l.Loan_Status == "InProgress")
                                {
                                    statuslist.Add(l);
                                }
                            break;
                        }
                    case "Completed":
                        {
                            foreach (Loan l in LoanList)
                                if (l.Loan_Status == "Completed")
                                {
                                    statuslist.Add(l);
                                }
                            break;
                        }
                }
                return statuslist;
            }

            //Loan By date
            public List<Loan> Loan_By_date(DateTime date)
            {
                List<Loan> datelist = new List<Loan>();
                foreach (Loan i in LoanList)
                {
                    if (i.loan_upload_date == date)
                    {
                        datelist.Add(i);
                    }
                }
                return datelist;
            }

            //Loan By Type
            public List<Loan> Loan_By_Type(string LT)
            {
                List<Loan> showlist = new List<Loan>();

                switch (LT)
                {
                    case "Car":
                        {
                            foreach (Loan l in LoanList)
                                if (l.Loan_Status == "Car")
                                {
                                    showlist.Add(l);
                                }
                            break;
                        }
                    case "Home":
                        {
                            //Link home loan with loan
                            foreach (Loan l in LoanList)
                                if (l.Loan_Status == "Home")
                                {
                                    showlist.Add(l);
                                }
                            break;
                        }
                    case "Educational":
                        {
                            foreach (Loan l in LoanList)
                                if (l.Loan_Status == "Educational")
                                {
                                    showlist.Add(l);
                                }
                            break;
                        }
                    case "Personal":
                        {
                            foreach (Loan l in LoanList)
                                if (l.Loan_Status == "Personal")
                                {
                                    showlist.Add(l);
                                }
                            break;
                        }
                }
                return showlist;
            }

            //loan by loan Id
            public Loan Loan_By_ID(string Loan_iD)
            {
                Loan loanSearch = null;
                foreach (Loan l in LoanList)
                {
                    if (l.loan_ID == Loan_iD)
                    {
                        loanSearch = l;
                    }
                }
                return loanSearch;
            }

            public double Eligible_Loan_Amt(CarLoan L)
            {
                return L.EligibleLoanAmt;
            }
            public string loan_approved(CarLoan L)
            {
                return L.Loan_Status;
            }
            public double EMI_Calculator(CarLoan L)
            {
                return L.EMI;
            }
        }
    }
}
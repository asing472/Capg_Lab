﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cheque.Entities;
using Pecunia.Exceptions;

namespace Cheque.DataAccessLayer
{
    public class ChequeBookDAL
    {
        public static List<ChequeBook> chequeBookRequestList = new List<ChequeBook>();
        public static List<ChequeBook> chequeBookApprovedList = new List<ChequeBook>();
        public bool ChequeBookRequestDAL(ChequeBook chequebook)
        {
            bool chequeBookRequested = false;
            try
            {
                chequebook.ChequeBookStatus = "Requested";
                chequeBookRequestList.Add(chequebook);
                chequeBookRequested = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return chequeBookRequested;

        }

        public List<ChequeBook> GetAllRequestedChequeBookListDAL()
        {
            return chequeBookRequestList;
        }
        public bool ChequeBookApprovedDAL(string deletechequebookId)
        {
            bool chequeBookApproved = false;
            try
            {
                ChequeBook deleteFromRequested = null;
                foreach (ChequeBook item in chequeBookRequestList)
                {
                    if (item.ChequeId == deletechequebookId)
                    {
                        deleteFromRequested = item;
                    }
                }

                if (deleteFromRequested != null)
                {
                    chequeBookRequestList.Remove(deleteFromRequested);
                    deleteFromRequested.ChequeBookStatus = "Approved";
                    chequeBookApprovedList.Add(deleteFromRequested);
                    chequeBookApproved = true;
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return chequeBookApproved;
        }
        public List<ChequeBook> GetAllApprovedChequeBookListDAL()
        {
            return chequeBookApprovedList;
        }


    }
}

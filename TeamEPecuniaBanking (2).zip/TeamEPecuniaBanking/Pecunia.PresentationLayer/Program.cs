﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Exceptions;

namespace Pecunia.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        CustomerService();
                        break;
                    case 2:
                       // AccountServices();
                        break;
                    case 3:
                        TransactionService();
                        break;
                    case 4:
                       // LoanServices();
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);

            void TransactionService()
            {
                int tChoice;
                do
                {
                    TransactionMenu();
                    Console.WriteLine("Enter your choice");
                    tChoice = Convert.ToInt32(Console.ReadLine());

                    switch (tChoice)
                    {
                        case 1:
                            Credit();
                            break;

                        case 2:
                            Debit();
                            break;
                        case 3:
                            Transfer();
                            break;
                        case 4:
                            GenerateReport();
                            break;
                    }


                } while (choice != -1);

            }


            void TransactionMenu()
            {
                Console.WriteLine("Select the service you want");
                Console.WriteLine("\n 1. Debit from account");
                Console.WriteLine("\n 2. credit from account");
                Console.WriteLine("\n 3. Transfer within accounts");
                Console.WriteLine("\n Generate Report");
            }

            void Debit()
            {
                Transaction transaction = new Transaction();
                Console.WriteLine("Enter Debit Account Number");
                transaction.DebitAccountNumber = Console.ReadLine();
                Console.WriteLine("Enter the amount you want to debit");
                transaction.Ammount = Convert.ToDouble(Console.ReadLine());
                transaction.TransactionType = "debit";
                transaction.TransactionTime = DateTime.Now;
                bool transactionDone = TransactionBL.DebitTransactionBL(transaction);
                if (transactionDone)
                    Console.WriteLine("Transaction Succesfull");
                else
                    Console.WriteLine("Transaction Failure");

            }
            void Credit()
            {
                Transaction transaction = new Transaction();
                Console.WriteLine("Enter Credit Account Number");
                transaction.CreditAccountNumber = Console.ReadLine();
                Console.WriteLine("Enter the amount you want to credit");
                transaction.Ammount = Convert.ToDouble(Console.ReadLine());
                transaction.TransactionType = "credit";
                transaction.TransactionTime = DateTime.Now;
                bool transactionDone = TransactionBL.CreditTransactionBL(transaction);
                if (transactionDone)
                    Console.WriteLine("Transaction Succesfull");
                else
                    Console.WriteLine("Transaction Failure");
            }
            void Transfer()
            {
                Transaction debitTransaction = new Transaction();
                Transaction creditTransaction = new Transaction();
                Console.WriteLine("Enter Credit Account Number");
                creditTransaction.CreditAccountNumber = Console.ReadLine();
                Console.WriteLine("Enter Debit Account Number");
                debitTransaction.DebitAccountNumber = Console.ReadLine();
                Console.WriteLine("Enter the amount you want to tarnsfer");
                debitTransaction.Ammount = Convert.ToDouble(Console.ReadLine());
                creditTransaction.Ammount = debitTransaction.Ammount;
                creditTransaction.TransactionType = "credit";
                debitTransaction.TransactionType = "debit";
                debitTransaction.TransactionTime = creditTransaction.TransactionTime = DateTime.Now;
                bool CreditTransactionDone = TransactionBL.CreditTransactionBL(creditTransaction);
                bool DebitTransactionDone = TransactionBL.DebitTransactionBL(debitTransaction);
                if (DebitTransactionDone)
                {
                    if (CreditTransactionDone)
                        Console.WriteLine("Transaction Succesfull");
                    else
                    {
                        Console.WriteLine("Transaction not Successful");
                    }
                }


            }
            void GenerateReport()
            {
                Console.WriteLine("Select the service you want");
                Console.WriteLine("\n 1. Transactions of a date");
                Console.WriteLine("\n 2. Transactions of a particuar account");
                Console.WriteLine("\n 3. Transaction by Transaction Type");
                int reportChoice= Convert.ToInt32(Console.ReadLine());
                switch (reportChoice)
                {
                    case 1:
                        Console.WriteLine("Enter Transacion Date");
                        DateTime time = Convert.ToDateTime(Console.ReadLine());
                        List<Transaction> transactionList = TransactionBL.GetAllTransactionByTimeBL(time);
                        foreach (Transaction item in transactionList)
                        {
                            Console.WriteLine(item.CreditAccountNumber + "\t" + item.DebitAccountNumber + "\t" + item.Ammount + "\t" + item.Ammount + "\t" + item.TransactionType);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter Account Number");
                        string acc = Console.ReadLine();
                        List<Transaction> transactionAccList = TransactionBL.GetAllTransactionByAccountNumberBL(acc);
                        foreach (Transaction item in transactionAccList)
                        {
                            Console.WriteLine(item.CreditAccountNumber + "\t" + item.DebitAccountNumber + "\t" + item.Ammount + "\t" + item.Ammount + "\t" + item.TransactionType);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter Transacion type");
                        string type = Console.ReadLine();
                        List<Transaction> transactionTypeList = TransactionBL.GetAllTransactionByTransactionTypeBL(type);
                        foreach (Transaction item in transactionTypeList)
                        {
                            Console.WriteLine(item.CreditAccountNumber +"\t"+  item.DebitAccountNumber + "\t" + item.Ammount + "\t" + item.Ammount + "\t" + item.TransactionTime);
                        }
                        break;
                }

                
            }
<<<<<<< HEAD


=======
            void CustomerService()
            {
                int option;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your Choice:\n ");
                    option = Convert.ToInt32(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                            AddCustomer();
                            break;
                        case 2:
                            ListAllCustomers();
                            break;
                        case 3:
                            SearchCustomerByID();
                            break;
                        case 4:
                            UpdateCustomer();
                            break;

                        case 5:
                            return;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (option != -1);
            }

            void PrintMenu()
            {
                Console.WriteLine("\n***********Customer Menu***********");
                Console.WriteLine("1. Add customer");
                Console.WriteLine("2. List All customers");
                Console.WriteLine("3. Search customer by ID");
                Console.WriteLine("4. Update customer");
                Console.WriteLine("5. Exit");

                Console.WriteLine("******************************************\n");

            }


            void UpdateCustomer()
            {
                try
                {
                    int updateCustomerID;
                    Console.WriteLine("Enter Customer ID to Update Details:");
                    updateCustomerID = Convert.ToInt32(Console.ReadLine());
                    Customer updateCustomer = CustomerBL.SearchCustomerBL(updateCustomerID);
                    if (updateCustomer != null)
                    {
                        Console.WriteLine("Update Customer Name :");
                        updateCustomer.CustomerName = Console.ReadLine();
                        Console.WriteLine("Update PhoneNumber :");
                        updateCustomer.CustomerContactNumber = Console.ReadLine();
                        bool customerUpdated = CustomerBL.UpdateCustomerBL(updateCustomer);
                        if (customerUpdated)
                            Console.WriteLine("Customer Details Updated");
                        else
                            Console.WriteLine("Customer Details not Updated ");
                    }
                    else
                    {
                        Console.WriteLine("No customer Details Available");
                    }


                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

             void SearchCustomerByID()
            {
                try
                {
                    int searchCustomer_ID;
                    Console.WriteLine("Enter Customer ID to Search:");
                    searchCustomer_ID = Convert.ToInt32(Console.ReadLine());
                    Customer searchCustomerID = CustomerBL.SearchCustomerBL(searchCustomer_ID);
                    if (searchCustomerID != null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("Customer ID\t\tName\t\tPhoneNumber");
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", searchCustomerID.CustomerID, searchCustomerID.CustomerName, searchCustomerID.CustomerContactNumber);
                        Console.WriteLine("******************************************************************************");
                    }
                    else
                    {
                        Console.WriteLine("No Customer Details Available");
                    }

                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


             void ListAllCustomers()
            {
                try
                {
                    List<Customer> customerList = CustomerBL.GetAllCustomersBL();
                    if (customerList != null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("Customer ID\t\tName\t\tPhoneNumber");
                        Console.WriteLine("******************************************************************************");
                        foreach (Customer customer in customerList)
                        {
                            Console.WriteLine("{0}\t\t{1}\t\t{2}", customer.CustomerID, customer.CustomerName, customer.CustomerContactNumber);
                        }
                        Console.WriteLine("******************************************************************************");

                    }
                    else
                    {
                        Console.WriteLine("No account Details Available");
                    }
                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

             void AddCustomer()
            {
                try
                {
                    Customer newCustomer = new Customer();

                    Console.WriteLine("Enter Customer ID :");
                    newCustomer.CustomerID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Customer Name :");
                    newCustomer.CustomerName = Console.ReadLine();
                    Console.WriteLine("Enter PhoneNumber :");
                    newCustomer.CustomerContactNumber = Console.ReadLine();
                    Console.WriteLine("Enter Customer Address:");
                    newCustomer.CustomerAddress = Console.ReadLine();
                    Console.WriteLine("Enter Customer Email ID:");
                    newCustomer.CustomerEmailID = Console.ReadLine();
                    Console.WriteLine("Enter Customer PAN no :");
                    newCustomer.CustomerPANno = Console.ReadLine();
                    Console.WriteLine("Enter Customer Aadhar no. :");
                    newCustomer.CustomerAadharno = Convert.ToInt64(Console.ReadLine());
                    Console.WriteLine("Enter Customer DOB :");
                    newCustomer.CustomerDOB = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Enter Customer Gender :");
                    newCustomer.CustomerGender = 
                       Convert.ToChar(Console.ReadLine());

                    bool customerCreated = CustomerBL.CreateCustomerBL(newCustomer);
                    if (customerCreated)
                        Console.WriteLine("Customer Added");
                    else
                        Console.WriteLine("Customer not Added");
                }
                catch (PecuniaException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            
        
    
>>>>>>> b3267cbc3effac2135657a3022465a7eb8c56011

            void PrintMenu()
            {
                Console.WriteLine("\n***********Guest PhoneBook Menu***********");
                Console.WriteLine("1. Customer Services");
                Console.WriteLine("2. Account Services");
                Console.WriteLine("3. Transaction Service");
                Console.WriteLine("4. Loan Services");
                Console.WriteLine("5. Exit");

                Console.WriteLine("******************************************\n");

            }
        }

        
    }
}

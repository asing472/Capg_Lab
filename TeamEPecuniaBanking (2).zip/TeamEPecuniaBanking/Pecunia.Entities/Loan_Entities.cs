﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loan_Entities
{
    public class Loan
    {
        public string loan_ID { get; set; }
        public string Loan_type { get; set; }
        public Double Loan_Amt { get; set; }
        public string Loan_Status { get; set; }
        public float Tenure { get; set; }
        public double YearlyIncome { get; set; }
        public double Years_of_service { get; set; }
        public double EligibleLoanAmt;
        public double EMI;
        public DateTime loan_upload_date;
    }





    //Car Loan
    public class CarLoan : Loan
    {
        public string License { get; set; }
    }


    //Home Loan
    public class HomeLoan : Loan
    {
        public double Collateral { get; set; }
    }


    //Education Loan
    public class EducationLoan : Loan
    {

        public double Collateral { get; set; }
        public string Sponseror { get; set; }
        public string College_name { get; set; }
        public string Admission_ID { get; set; }
    }


    //Personal Loan
    public class PersonalLoan : Loan
    {

        public double Collateral { get; set; }
    }




}
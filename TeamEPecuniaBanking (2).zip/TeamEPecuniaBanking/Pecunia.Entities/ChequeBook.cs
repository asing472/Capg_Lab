﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cheque.Entities
{

    public class ChequeBook
    {
        

        public string AccountNo { get; set; }
       
        
        public string CustomerName{ get; set; }
        
        public string ChequeId { get; set; }

         
        
        public int NumberOfLeaves { get; set; }
        

        
        public string ChequeBookStatus { get; set; }
        

    }
}
